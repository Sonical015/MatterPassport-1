import { asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import {
  buildings,
  events,
  materials,
  requirements,
  type Building,
  type Material,
  type PassportEvent,
  type Requirement,
} from "@/db/schema";
import {
  assessPathway,
  CONDITION_RANK,
  massCoverage,
  stateAfterRecovery,
  type PathwayKey,
} from "./lifecycle";

export type MaterialRef = string;

function resolveCode(ref: string): { code?: string; id?: number } {
  const value = decodeURIComponent(ref).trim().toUpperCase();
  if (/^MP-\d{3,6}$/.test(value)) return { code: value };
  if (/^\d+$/.test(value)) return { id: Number(value) };
  return { code: value };
}

export async function listBuildings(): Promise<Building[]> {
  await ensureSeeded();
  return db.select().from(buildings).orderBy(asc(buildings.id));
}

export async function getBuilding(ref: string): Promise<Building | null> {
  await ensureSeeded();
  const { code, id } = resolveCode(ref);
  const rows = await db
    .select()
    .from(buildings)
    .where(id ? eq(buildings.id, id) : eq(buildings.code, code ?? ref));
  return rows[0] ?? null;
}

export async function listMaterials(): Promise<Material[]> {
  await ensureSeeded();
  return db.select().from(materials).orderBy(asc(materials.id));
}

export async function listEvents(): Promise<PassportEvent[]> {
  await ensureSeeded();
  return db.select().from(events).orderBy(asc(events.id));
}

export async function listRequirements(): Promise<Requirement[]> {
  await ensureSeeded();
  return db.select().from(requirements).orderBy(asc(requirements.id));
}

export type Passport = {
  material: Material;
  events: PassportEvent[];
  building: Building | null;
  originBuilding: Building | null;
};

export async function getPassport(ref: MaterialRef): Promise<Passport | null> {
  await ensureSeeded();
  const { code, id } = resolveCode(ref);
  const rows = await db
    .select()
    .from(materials)
    .where(id ? eq(materials.id, id) : eq(materials.code, code ?? ref));
  const material = rows[0];
  if (!material) return null;

  const log = await db
    .select()
    .from(events)
    .where(eq(events.materialId, material.id))
    .orderBy(asc(events.seq));

  const ids = new Set<number>();
  if (material.buildingId) ids.add(material.buildingId);
  if (material.originBuildingId) ids.add(material.originBuildingId);
  if (material.recoveredFromBuildingId) ids.add(material.recoveredFromBuildingId);
  const related = ids.size
    ? await db.select().from(buildings).where(inArray(buildings.id, [...ids]))
    : [];

  return {
    material,
    events: log,
    building: related.find((b) => b.id === material.buildingId) ?? null,
    originBuilding: related.find((b) => b.id === material.originBuildingId) ?? null,
  };
}

export async function getBuildingInventory(buildingId: number) {
  await ensureSeeded();
  const items = await db
    .select()
    .from(materials)
    .where(eq(materials.buildingId, buildingId))
    .orderBy(asc(materials.id));
  const reqs = await db
    .select()
    .from(requirements)
    .where(eq(requirements.buildingId, buildingId))
    .orderBy(asc(requirements.id));
  return { items, requirements: reqs };
}

/* ------------------------------------------------------------------ */
/* Dataset statistics — always the true size of the exhibit dataset.  */
/* ------------------------------------------------------------------ */

export async function getDatasetStats() {
  await ensureSeeded();
  const [mats, evts, reqs, blds] = await Promise.all([
    db.select().from(materials),
    db.select().from(events),
    db.select().from(requirements),
    db.select().from(buildings),
  ]);
  const totalMass = mats.reduce((sum, m) => sum + m.massKg, 0);
  const inBuildings = mats.filter((m) => m.buildingId !== null);
  return {
    materialCount: mats.length,
    eventCount: evts.length,
    requirementCount: reqs.length,
    buildingCount: blds.length,
    openRequirementCount: reqs.filter((r) => r.status !== "filled").length,
    trackedMassKg: totalMass,
    assignedMassKg: inBuildings.reduce((sum, m) => sum + m.massKg, 0),
    classes: [...new Set(mats.map((m) => m.materialClass))].sort(),
  };
}

/* ------------------------------------------------------------------ */
/* Deconstruction + recovery report                                   */
/* ------------------------------------------------------------------ */

export type RecoveryReport = {
  building: Building;
  lines: Array<{
    material: Material;
    outcome: PathwayKey;
  }>;
  totals: Record<PathwayKey, { count: number; mass: number }>;
  componentCount: number;
  totalMass: number;
  recoveredMass: number;
  unrecoverableMass: number;
  recoveryPct: number;
  alreadyDeconstructed: boolean;
};

export async function getRecoveryReport(ref: string): Promise<RecoveryReport | null> {
  await ensureSeeded();
  const building = await getBuilding(ref);
  if (!building) return null;

  const lines = (
    await db
      .select()
      .from(materials)
      .where(eq(materials.recoveredFromBuildingId, building.id))
      .orderBy(asc(materials.id))
  ).map((material) => ({
    material,
    outcome: (material.recoveryOutcome ?? "unrecoverable") as PathwayKey,
  }));

  const totals = {
    reuse: { count: 0, mass: 0 },
    repurpose: { count: 0, mass: 0 },
    recycle: { count: 0, mass: 0 },
    unrecoverable: { count: 0, mass: 0 },
  } satisfies RecoveryReport["totals"];

  for (const line of lines) {
    totals[line.outcome].count += 1;
    totals[line.outcome].mass += line.material.massKg;
  }

  const totalMass = lines.reduce((s, l) => s + l.material.massKg, 0);
  const unrecoverableMass = totals.unrecoverable.mass;
  const recoveredMass = totalMass - unrecoverableMass;

  return {
    building,
    lines,
    totals,
    componentCount: lines.length,
    totalMass,
    recoveredMass,
    unrecoverableMass,
    recoveryPct: totalMass > 0 ? (recoveredMass / totalMass) * 100 : 0,
    alreadyDeconstructed: building.status === "deconstructed",
  };
}

export async function deconstructBuilding(ref: string): Promise<
  | { ok: false; reason: "not_found" | "no_components" }
  | { ok: true; report: RecoveryReport }
> {
  await ensureSeeded();
  const building = await getBuilding(ref);
  if (!building) return { ok: false, reason: "not_found" };

  const components = await db
    .select()
    .from(materials)
    .where(eq(materials.buildingId, building.id));

  const live = components.filter((m) =>
    ["in_service", "repaired", "second_life"].includes(m.state),
  );
  if (live.length === 0) return { ok: false, reason: "no_components" };

  const now = new Date().toISOString().replace(/\.\d+Z$/, "Z");
  const maxEvent = await db
    .select({ id: events.id })
    .from(events)
    .orderBy(desc(events.id))
    .limit(1);
  let eventId = (maxEvent[0]?.id ?? 0) + 1;

  let index = 0;
  for (const material of live) {
    const outcome = assessPathway({
      recommendedPathway: material.recommendedPathway,
      condition: material.condition,
      materialClass: material.materialClass,
    });
    const nextState = stateAfterRecovery(outcome);
    const row = 1 + Math.floor(index / 4);
    index += 1;

    await db
      .update(materials)
      .set({
        state: nextState,
        buildingId: null,
        recoveredFromBuildingId: building.id,
        recoveryOutcome: outcome,
        locationRef:
          outcome === "unrecoverable"
            ? "Closed at deconstruction"
            : `Recovery yard Delft · row ${row}`,
        secondLifeNote: null,
      })
      .where(eq(materials.id, material.id));

    await db.insert(events).values([
      {
        id: eventId++,
        materialId: material.id,
        seq: 900,
        type: "DECONSTRUCTED",
        label: "Deconstructed",
        occurredAt: now,
        actor: "Deconstruct crew · exhibit",
        site: `${building.code} · ${building.name}`,
        detail: `Removed from ${material.locationRef}. Connection released without cutting the identity plate.`,
      },
      {
        id: eventId++,
        materialId: material.id,
        seq: 901,
        type: outcome === "unrecoverable" ? "CLOSED" : "RECOVERED",
        label:
          outcome === "unrecoverable"
            ? "Record closed"
            : "Assessed + recovered to store",
        occurredAt: now,
        actor: "MatterPassport registry node NL-01",
        site:
          outcome === "unrecoverable"
            ? `${building.code} · site`
            : "Recovery yard Delft",
        detail:
          outcome === "unrecoverable"
            ? `No separation route available. Assessed pathway: UNRECOVERABLE. Mass retained in ledger, identity closed.`
            : `Assessed pathway: ${outcome.toUpperCase()}. Recorded condition ${material.condition}. Declared specification retained.`,
      },
    ]);
  }

  await db
    .update(buildings)
    .set({ status: "deconstructed" })
    .where(eq(buildings.id, building.id));

  const report = await getRecoveryReport(String(building.code));
  if (!report) return { ok: false, reason: "not_found" };
  return { ok: true, report };
}

/* ------------------------------------------------------------------ */
/* Second-life matching                                               */
/* ------------------------------------------------------------------ */

export type MatchCandidate = {
  requirement: Requirement;
  building: Building;
  coverage: number;
  massAvailableKg: number;
  massRequiredKg: number;
  verdict: "MATCH" | "NO MATCH";
  reason: string;
};

export type MatchResult = {
  material: Material;
  candidates: MatchCandidate[];
  openRequirementCount: number;
  eligibleOutcomes: string[];
};

const MATCHABLE_OUTCOMES = ["reuse", "repurpose"];

export async function findMatches(ref: MaterialRef): Promise<MatchResult | null> {
  await ensureSeeded();
  const { code, id } = resolveCode(ref);
  const rows = await db
    .select()
    .from(materials)
    .where(id ? eq(materials.id, id) : eq(materials.code, code ?? ref));
  const material = rows[0];
  if (!material) return null;

  const allRequirements = await db
    .select()
    .from(requirements)
    .where(sql`${requirements.status} <> 'filled'`);
  const allBuildings = await db.select().from(buildings);

  const released =
    material.state === "recovered" ||
    (material.state === "registered" && material.buildingId === null);
  const outcome = material.recoveryOutcome ?? material.recommendedPathway;
  const eligible = released && MATCHABLE_OUTCOMES.includes(outcome);

  const candidates: MatchCandidate[] = allRequirements.map((requirement) => {
    const building = allBuildings.find((b) => b.id === requirement.buildingId);
    let verdict: "MATCH" | "NO MATCH" = "NO MATCH";
    let reason = "";

    if (!building) {
      reason = "Requirement has no building record";
    } else if (requirement.filledByMaterialId === material.id) {
      reason = "Already filled by this identity";
    } else if (requirement.materialClass !== material.materialClass) {
      reason = `Class mismatch · requires ${requirement.materialClass.toUpperCase()}`;
    } else if (
      (CONDITION_RANK[material.condition] ?? 0) <
      (CONDITION_RANK[requirement.minCondition] ?? 0)
    ) {
      reason = `Condition ${material.condition} below threshold ${requirement.minCondition}`;
    } else if (!released) {
      reason = `Still in custody of a building record · state ${material.state
        .replace(/_/g, " ")
        .toUpperCase()}`;
    } else if (!eligible) {
      reason = `Assessed pathway ${outcome.toUpperCase()} is not element-retaining`;
    } else if (requirement.buildingId === material.originBuildingId) {
      reason = "Requirement held by building of origin";
    } else {
      verdict = "MATCH";
      reason = `Class + condition satisfied · ${massCoverage(
        material.massKg,
        requirement.massRequiredKg,
      )}% of required mass`;
    }

    return {
      requirement,
      building: building as Building,
      coverage: massCoverage(material.massKg, requirement.massRequiredKg),
      massAvailableKg: material.massKg,
      massRequiredKg: requirement.massRequiredKg,
      verdict,
      reason,
    };
  });

  candidates.sort((a, b) => {
    const score = (c: MatchCandidate) =>
      c.verdict === "MATCH" ? (c.coverage >= 100 ? 0 : 1) : 2;
    return score(a) - score(b) || a.requirement.id - b.requirement.id;
  });

  return {
    material,
    candidates,
    openRequirementCount: allRequirements.length,
    eligibleOutcomes: MATCHABLE_OUTCOMES,
  };
}

export async function assignSecondLife(
  materialRef: MaterialRef,
  requirementId: number,
): Promise<{ ok: boolean; error?: string; materialCode?: string }> {
  await ensureSeeded();
  const result = await findMatches(materialRef);
  if (!result) return { ok: false, error: "material_not_found" };
  const candidate = result.candidates.find(
    (c) => c.requirement.id === requirementId,
  );
  if (!candidate) return { ok: false, error: "requirement_not_found" };
  if (candidate.verdict !== "MATCH")
    return { ok: false, error: "not_eligible", materialCode: result.material.code };

  const material = result.material;
  const { requirement, building, coverage } = candidate;
  const now = new Date().toISOString().replace(/\.\d+Z$/, "Z");
  const maxEvent = await db
    .select({ id: events.id })
    .from(events)
    .orderBy(desc(events.id))
    .limit(1);
  const eventId = (maxEvent[0]?.id ?? 0) + 1;

  await db
    .update(materials)
    .set({
      state: "second_life",
      buildingId: building.id,
      locationRef: `${building.code} · staged for ${requirement.code}`,
      secondLifeNote: `Assigned to ${requirement.code} in ${building.code} (${building.name}). Mass coverage ${coverage}%.`,
    })
    .where(eq(materials.id, material.id));

  await db
    .update(requirements)
    .set({ status: "filled", filledByMaterialId: material.id })
    .where(eq(requirements.id, requirement.id));

  await db.insert(events).values({
    id: eventId,
    materialId: material.id,
    seq: 950,
    type: "REASSIGNED",
    label: "Second life assigned",
    occurredAt: now,
    actor: "MatterPassport registry node NL-01",
    site: `${building.code} · ${building.name}`,
    detail: `Matched to ${requirement.code} · ${requirement.spec}. Mass coverage ${coverage}%. Condition ${material.condition} against threshold ${requirement.minCondition}.`,
  });

  return { ok: true, materialCode: material.code };
}

/* ------------------------------------------------------------------ */
/* Registration                                                       */
/* ------------------------------------------------------------------ */

export type RegisterInput = {
  name: string;
  materialClass: string;
  componentType: string;
  massKg: number;
  dimensions: string;
  condition: string;
  manufacturer: string;
  manufactureSite: string;
  manufacturedAt: string;
  batchRef: string;
  recommendedPathway: string;
  locationRef: string;
  buildingCode: string;
  declaredSpecs: Record<string, string>;
};

export async function registerMaterial(
  input: RegisterInput,
): Promise<{ code: string; id: number }> {
  await ensureSeeded();
  const maxMaterial = await db
    .select({ id: materials.id })
    .from(materials)
    .orderBy(desc(materials.id))
    .limit(1);
  const nextId = Math.max(maxMaterial[0]?.id ?? 0, 306) + 1;
  const code = `MP-${String(nextId).padStart(6, "0")}`;

  let buildingId: number | null = null;
  if (input.buildingCode) {
    const b = await getBuilding(input.buildingCode);
    buildingId = b?.id ?? null;
  }

  const now = new Date().toISOString().replace(/\.\d+Z$/, "Z");
  const maxEvent = await db
    .select({ id: events.id })
    .from(events)
    .orderBy(desc(events.id))
    .limit(1);
  let eventId = (maxEvent[0]?.id ?? 0) + 1;

  await db.insert(materials).values({
    id: nextId,
    code,
    name: input.name,
    materialClass: input.materialClass,
    componentType: input.componentType,
    massKg: input.massKg,
    dimensions: input.dimensions,
    condition: input.condition,
    state: buildingId ? "registered" : "registered",
    recommendedPathway: input.recommendedPathway,
    manufacturer: input.manufacturer,
    manufactureSite: input.manufactureSite,
    manufacturedAt: input.manufacturedAt,
    batchRef: input.batchRef,
    originBuildingId: buildingId,
    buildingId,
    locationRef: input.locationRef,
    declaredSpecs: input.declaredSpecs,
    schematic: { x: 0.92, y: 0.9, w: 0.05, h: 0.05, layer: 0, label: "NEW" },
    recoveredFromBuildingId: null,
    recoveryOutcome: null,
    secondLifeNote: null,
  });

  await db.insert(events).values([
    {
      id: eventId++,
      materialId: nextId,
      seq: 1,
      type: "MANUFACTURED",
      label: "Manufactured",
      occurredAt: `${input.manufacturedAt}T08:00:00Z`,
      actor: `${input.manufacturer} · declared`,
      site: input.manufactureSite,
      detail: `Declared by manufacturer. Batch ${input.batchRef}. No sensing performed at any stage of this record.`,
    },
    {
      id: eventId++,
      materialId: nextId,
      seq: 2,
      type: "REGISTERED",
      label: "Identity issued",
      occurredAt: now,
      actor: "MatterPassport registry node NL-01",
      site: "Registry NL-01",
      detail: `Identity ${code} bound to declared specification set. Carrier: QR (current MatterMark implementation).`,
    },
  ]);

  return { code, id: nextId };
}
