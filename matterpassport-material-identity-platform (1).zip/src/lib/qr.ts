import QRCode from "qrcode";
import { headers } from "next/headers";

export function matterMarkPayload(code: string, origin: string) {
  return `${origin}/material/${code}`;
}

export async function getOrigin() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

/**
 * Current MatterMark implementation: a QR carrier.
 * The identity layer is carrier-agnostic — see /register for the note.
 */
export async function renderMatterMark(payload: string) {
  const svg = await QRCode.toString(payload, {
    type: "svg",
    margin: 0,
    errorCorrectionLevel: "M",
    color: { dark: "#d8dbdd", light: "#08090a" },
  });
  return svg;
}
