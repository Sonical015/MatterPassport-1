export type LifecycleState =
  | "manufactured"
  | "registered"
  | "in_service"
  | "repaired"
  | "recovered"
  | "second_life"
  | "recycled"
  | "repurposed"
  | "unrecoverable";

export const STATE_ORDER: LifecycleState[] = [
  "manufactured",
  "registered",
  "in_service",
  "repaired",
  "recovered",
  "second_life",
];

export const STATE_LABEL: Record<LifecycleState, string> = {
  manufactured: "MANUFACTURED",
  registered: "REGISTERED",
  in_service: "IN SERVICE",
  repaired: "REPAIRED · IN SERVICE",
  recovered: "RECOVERED · HELD",
  second_life: "SECOND LIFE",
  recycled: "RECYCLED · IDENTITY CLOSED",
  repurposed: "REPURPOSED",
  unrecoverable: "UNRECOVERABLE · IDENTITY CLOSED",
};

export const STATE_SHORT: Record<LifecycleState, string> = {
  manufactured: "MFG",
  registered: "REG",
  in_service: "IN SERVICE",
  repaired: "REPAIRED",
  recovered: "HELD",
  second_life: "2ND LIFE",
  recycled: "RECYCLED",
  repurposed: "REPURPOSED",
  unrecoverable: "UNRECOVERABLE",
};

export const STATE_NOTE: Record<LifecycleState, string> = {
  manufactured: "Physical object exists. Identity not yet issued.",
  registered: "Identity bound to a declared specification set.",
  in_service: "Installed and under custody of a building record.",
  repaired: "Intervention logged against the same identity.",
  recovered: "Deconstructed, assessed, held at a recovery store.",
  second_life: "Reassigned to a new building requirement.",
  recycled: "Sent to melt / reprocessing. Mass retained, form lost.",
  repurposed: "Reused off-building in a non-structural role.",
  unrecoverable: "Cannot be separated or reused. Record closed.",
};

export const PATHWAYS = [
  {
    key: "reuse",
    label: "REUSE",
    definition:
      "Element removed whole, identity and declared specification retained, reinstalled in another building.",
  },
  {
    key: "repurpose",
    label: "REPURPOSE",
    definition:
      "Element kept intact but downgraded to a non-structural or non-original role.",
  },
  {
    key: "recycle",
    label: "RECYCLE",
    definition:
      "Element reprocessed as material. Mass conserved, form and declared section lost.",
  },
  {
    key: "unrecoverable",
    label: "UNRECOVERABLE",
    definition:
      "Element cannot be separated from adjacent matter without destruction. Recorded, then closed.",
  },
] as const;

export type PathwayKey = (typeof PATHWAYS)[number]["key"];

export const CONDITION_RANK: Record<string, number> = { A: 3, B: 2, C: 1 };

export const CONDITION_NOTE: Record<string, string> = {
  A: "No recorded defect. Declared specification intact.",
  B: "Recorded defect or repair that does not impair the declared section.",
  C: "Recorded defect or processing that prevents reuse as-declared.",
};

export const MATERIAL_CLASSES = [
  "steel",
  "aluminium",
  "timber",
  "concrete",
  "glass",
  "mineral",
  "polymer",
] as const;

/**
 * Recovery assessment applied at deconstruction. Shown verbatim on the
 * recovery report so every pathway count can be traced to a rule.
 */
export function assessPathway(input: {
  recommendedPathway: string;
  condition: string;
  materialClass: string;
}): PathwayKey {
  const { recommendedPathway, condition, materialClass } = input;
  if (recommendedPathway === "unrecoverable") return "unrecoverable";
  if (condition !== "C") return (recommendedPathway as PathwayKey) ?? "recycle";
  // Condition C: the element can no longer be reused as-declared.
  if (recommendedPathway === "reuse") {
    return materialClass === "glass" ? "recycle" : "repurpose";
  }
  return (recommendedPathway as PathwayKey) ?? "recycle";
}

export function stateAfterRecovery(pathway: PathwayKey): LifecycleState {
  if (pathway === "unrecoverable") return "unrecoverable";
  return "recovered";
}

/* ---------- formatting ---------- */

export function fmtMass(kg: number): string {
  if (Math.abs(kg) >= 1000) return `${(kg / 1000).toFixed(3)} t`;
  return `${kg.toFixed(1)} kg`;
}

export function fmtMassKg(kg: number): string {
  return `${kg.toLocaleString("en-GB", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  })} kg`;
}

export function fmtStamp(iso: string): string {
  // 2019-01-08T08:20:00Z -> 2019-01-08 08:20 UTC
  const d = iso.slice(0, 10);
  const t = iso.slice(11, 16);
  return t ? `${d} ${t} UTC` : d;
}

export function fmtDate(iso: string): string {
  return iso.slice(0, 10);
}

export function classLabel(c: string): string {
  return c.toUpperCase();
}

/** Mass coverage: the only compatibility figure used anywhere in the exhibit. */
export function massCoverage(availableKg: number, requiredKg: number): number {
  if (requiredKg <= 0) return 0;
  return Math.min(100, Math.round((availableKg / requiredKg) * 100));
}

export function coverageFormula(): string {
  return "coverage = min(100, mass_available ÷ mass_required × 100)";
}
