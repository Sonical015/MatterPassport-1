import { getOrigin, matterMarkPayload, renderMatterMark } from "@/lib/qr";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const code = new URL(request.url).searchParams.get("code")?.trim() ?? "";
  if (!/^MP-\d{3,8}$/i.test(code)) {
    return new Response("invalid identity string", { status: 400 });
  }
  const origin = await getOrigin();
  const svg = await renderMatterMark(matterMarkPayload(code.toUpperCase(), origin));
  return new Response(svg, {
    headers: {
      "content-type": "image/svg+xml",
      "cache-control": "no-store",
    },
  });
}
