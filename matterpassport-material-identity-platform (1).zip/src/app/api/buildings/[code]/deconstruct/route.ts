import { deconstructBuilding } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ code: string }> },
) {
  const { code } = await params;
  const result = await deconstructBuilding(code);
  if (!result.ok) {
    return Response.json(result, { status: 409 });
  }
  return Response.json({
    ok: true,
    componentCount: result.report.componentCount,
    totalMass: result.report.totalMass,
    recoveryPct: result.report.recoveryPct,
    totals: result.report.totals,
  });
}
