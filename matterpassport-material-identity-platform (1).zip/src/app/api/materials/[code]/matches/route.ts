import { findMatches } from "@/lib/data";
import { coverageFormula } from "@/lib/lifecycle";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ code: string }> },
) {
  const { code } = await params;
  const result = await findMatches(code);
  if (!result) {
    return Response.json({ ok: false, error: "material_not_found" }, { status: 404 });
  }
  return Response.json({
    ok: true,
    formula: coverageFormula(),
    material: {
      code: result.material.code,
      materialClass: result.material.materialClass,
      condition: result.material.condition,
      massKg: result.material.massKg,
      recoveryOutcome: result.material.recoveryOutcome,
      recommendedPathway: result.material.recommendedPathway,
      state: result.material.state,
    },
    openRequirementCount: result.openRequirementCount,
    eligibleOutcomes: result.eligibleOutcomes,
    candidates: result.candidates.map((c) => ({
      id: c.requirement.id,
      code: c.requirement.code,
      buildingCode: c.building?.code ?? "—",
      buildingName: c.building?.name ?? "—",
      materialClass: c.requirement.materialClass,
      spec: c.requirement.spec,
      massRequiredKg: c.requirement.massRequiredKg,
      minCondition: c.requirement.minCondition,
      status: c.requirement.status,
      verdict: c.verdict,
      reason: c.reason,
      coverage: c.coverage,
    })),
  });
}
