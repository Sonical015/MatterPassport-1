import { assignSecondLife } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ code: string }> },
) {
  const { code } = await params;
  let requirementId = 0;
  try {
    const body = (await request.json()) as { requirementId?: number };
    requirementId = Number(body.requirementId);
  } catch {
    return Response.json({ ok: false, error: "invalid_body" }, { status: 400 });
  }

  if (!Number.isFinite(requirementId) || requirementId <= 0) {
    return Response.json({ ok: false, error: "requirement_required" }, { status: 400 });
  }

  const result = await assignSecondLife(code, requirementId);
  if (!result.ok) {
    return Response.json(result, { status: 409 });
  }
  return Response.json(result);
}
