import { registerMaterial, type RegisterInput } from "@/lib/data";

export const dynamic = "force-dynamic";

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function num(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "invalid_body" }, { status: 400 });
  }

  const name = str(body.name);
  if (!name) {
    return Response.json({ ok: false, error: "name_required" }, { status: 400 });
  }

  const specs = (body.declaredSpecs ?? {}) as Record<string, unknown>;
  const declaredSpecs: Record<string, string> = {};
  for (const [k, v] of Object.entries(specs)) {
    if (typeof v === "string" && v.trim()) declaredSpecs[k] = v.trim();
  }

  const input: RegisterInput = {
    name,
    materialClass: str(body.materialClass, "steel"),
    componentType: str(body.componentType, "component"),
    massKg: num(body.massKg, 1),
    dimensions: str(body.dimensions, "—"),
    condition: str(body.condition, "A"),
    manufacturer: str(body.manufacturer, "Declared by registrant"),
    manufactureSite: str(body.manufactureSite, "—"),
    manufacturedAt: str(body.manufacturedAt, new Date().toISOString().slice(0, 10)),
    batchRef: str(body.batchRef, "—"),
    recommendedPathway: str(body.recommendedPathway, "reuse"),
    locationRef: str(body.locationRef, "Unassigned · not yet in a building"),
    buildingCode: str(body.buildingCode),
    declaredSpecs,
  };

  try {
    const { code } = await registerMaterial(input);
    return Response.json({ ok: true, code, path: `/material/${code}` });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "unknown" },
      { status: 500 },
    );
  }
}
