import { getPassport } from "@/lib/data";

export const dynamic = "force-dynamic";

/** Lookup by identity string, exactly as the scan console does. */
export async function GET(request: Request) {
  const query = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  if (!query) {
    return Response.json({ status: "empty_query", query }, { status: 400 });
  }

  const passport = await getPassport(query);
  if (!passport) {
    return Response.json({ status: "not_found", query }, { status: 404 });
  }

  return Response.json({
    status: "found",
    query,
    material: {
      code: passport.material.code,
      name: passport.material.name,
      state: passport.material.state,
      massKg: passport.material.massKg,
      materialClass: passport.material.materialClass,
      locationRef: passport.material.locationRef,
    },
    path: `/material/${passport.material.code}`,
  });
}
