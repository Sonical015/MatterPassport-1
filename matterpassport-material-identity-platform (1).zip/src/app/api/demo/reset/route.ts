import { resetDemo } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await resetDemo();
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "unknown" },
      { status: 500 },
    );
  }
}
