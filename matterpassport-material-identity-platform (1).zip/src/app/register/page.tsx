import Link from "next/link";
import { listBuildings, getDatasetStats } from "@/lib/data";
import { RegisterForm } from "@/components/register-form";
import { Note, SectionTitle } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ legacy?: string; ref?: string }>;
}) {
  const { legacy, ref } = await searchParams;
  const [buildings, stats] = await Promise.all([listBuildings(), getDatasetStats()]);

  return (
    <div className="grid gap-6">
      <SectionTitle
        index="/ REGISTER"
        title="Issue an identity"
        note="Registration binds an identity string to a declared specification set and, if known, to a building record. This is the only write path in the exhibit: everything after this point is appended as custody events."
      />

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,340px)]">
        <RegisterForm
          buildings={buildings.map((b) => ({ code: b.code, name: b.name }))}
          legacy={legacy === "1"}
          legacyRef={ref ?? ""}
        />

        <aside className="grid content-start gap-4">
          <div className="hair">
            <div className="rule-b bg-[#0f1215] px-3 py-2">
              <h2 className="label !text-[color:var(--color-ink-dim)]">
                Carrier note
              </h2>
            </div>
            <div className="grid gap-3 px-3 py-3">
              <p className="mono text-[11px] leading-relaxed text-[color:var(--color-ink-dim)]">
                MATTERMARK · CURRENT IMPLEMENTATION: QR
                <br />
                ERROR CORRECTION: M · MODULES: 25×25
              </p>
              <Note>
                The identity layer is carrier-agnostic. A QR code is what this
                exhibit can print and read today. The same identity string can
                be carried by an RFID tag, an NFC chip, a laser-etched code on
                a steel flange, or a printed optical mark, without changing a
                single row in the registry.
              </Note>
              <Note>
                On the physical model beside this screen, each QR mark is
                attached to one component. Reading it with the{" "}
                <Link href="/scan" className="text-[color:var(--color-accent)] underline">
                  scan console
                </Link>{" "}
                resolves the identity string.
              </Note>
            </div>
          </div>

          <div className="hair">
            <div className="rule-b bg-[#0f1215] px-3 py-2">
              <h2 className="label !text-[color:var(--color-ink-dim)]">
                Registry state before this write
              </h2>
            </div>
            <dl className="mono grid gap-[6px] px-3 py-3 text-[11px] text-[color:var(--color-ink-dim)]">
              {[
                ["Material identities held", `${stats.materialCount}`],
                ["Building records", `${stats.buildingCount}`],
                ["Logged events", `${stats.eventCount}`],
                ["Declared mass under identity", `${stats.trackedMassKg.toFixed(1)} kg`],
                ["Open requirements", `${stats.openRequirementCount}`],
              ].map(([k, v]) => (
                <div key={k} className="grid grid-cols-[1fr_auto] gap-3">
                  <dt className="label">{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
            <p className="rule-t bg-[#0a0c0e] px-3 py-2 text-[11.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
              These are the true contents of this node. The next identity issued
              will be sequential and visible immediately in the header of every
              page.
            </p>
          </div>

          <div className="hair">
            <div className="rule-b bg-[#0f1215] px-3 py-2">
              <h2 className="label !text-[color:var(--color-ink-dim)]">
                What is not collected
              </h2>
            </div>
            <ul className="mono grid gap-1 px-3 py-3 text-[11px] text-[color:var(--color-ink-faint)]">
              <li>· no measurements or sensing of any kind</li>
              <li>· no material classification or inference</li>
              <li>· no statistical confidence scoring</li>
              <li>· no score, rating or certification of any kind</li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
