import Link from "next/link";
import { FailureState, SectionTitle } from "@/components/ui";

export default function NotFound() {
  return (
    <div className="grid gap-6">
      <SectionTitle
        index="/ 404"
        title="Lookup returned no record"
        note="The registry was asked for a record it does not hold. Nothing was inferred, nothing was suggested."
      />
      <FailureState
        code="LOOKUP FAILED · 404"
        title="RECORD NOT FOUND IN REGISTRY NODE NL-01"
        lines={[
          "The identity string requested does not resolve to a material, building or page in this node.",
          "Possible causes: mistyped identity string · record issued by another node · record never issued · page removed from the exhibit.",
          "This registry does not fuzzy-match, and it does not substitute a nearest neighbour. Matter is identified exactly, or it is not identified.",
        ]}
        action={
          <div className="flex flex-wrap gap-2">
            <Link href="/scan" className="btn btn-primary">
              ▸ Manual identity entry
            </Link>
            <Link href="/ledger" className="btn">
              Search the ledger
            </Link>
            <Link href="/" className="btn">
              Return to concept
            </Link>
          </div>
        }
      />
      <div className="hair">
        <div className="rule-b bg-[#0f1215] px-3 py-2">
          <h2 className="label !text-[color:var(--color-ink-dim)]">
            Note on this state
          </h2>
        </div>
        <p className="px-3 py-3 text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
          A missing record is a normal condition of a registry, not an error of
          the interface. If the object exists but cannot be identified, the
          correct action is to issue a new identity through registration —
          which starts a new record rather than guessing at an old one.
        </p>
      </div>
    </div>
  );
}
