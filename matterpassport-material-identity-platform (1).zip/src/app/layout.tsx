import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";
import { getDatasetStats } from "@/lib/data";
import { UtcClock } from "@/components/utc-clock";
import { PresentationMode } from "@/components/presentation-mode";
import { fmtMassKg } from "@/lib/lifecycle";

export const metadata: Metadata = {
  title: "MatterPassport · registry node NL-01",
  description:
    "A persistent identity for manufactured matter across manufacture, construction, deconstruction and second life. Exhibit prototype.",
};

const NAV = [
  ["/", "Concept"],
  ["/scan", "Scan / Lookup"],
  ["/register", "Register"],
  ["/ledger", "Ledger"],
  ["/compare", "Compare"],
] as const;

export default async function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  const stats = await getDatasetStats();

  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <div className="blueprint flex min-h-screen flex-col">
          <header className="no-print rule-b sticky top-0 z-40 bg-[#0a0c0e]/96 backdrop-blur">
            <div className="mx-auto flex max-w-[1400px] flex-wrap items-center gap-x-6 gap-y-2 px-4 py-2">
              <Link href="/" className="group flex items-baseline gap-3">
                <span className="mono text-[13px] tracking-[0.24em] text-[color:var(--color-ink)]">
                  MATTERPASSPORT
                </span>
                <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                  REGISTRY NODE NL-01
                </span>
              </Link>
              <nav className="mono flex flex-wrap items-center gap-1 text-[10.5px] tracking-[0.14em] uppercase">
                {NAV.map(([href, label]) => (
                  <Link
                    key={href}
                    href={href}
                    className="border border-transparent px-2 py-1 text-[color:var(--color-ink-dim)] hover:border-[color:var(--color-hairline)] hover:text-[color:var(--color-accent)]"
                  >
                    {label}
                  </Link>
                ))}
              </nav>
              <div className="ml-auto flex items-center gap-5">
                <span className="mono hidden text-[10px] tracking-[0.1em] text-[color:var(--color-ink-faint)] lg:inline">
                  DATASET · {stats.materialCount} MATERIALS ·{" "}
                  {stats.buildingCount} BUILDINGS · {stats.eventCount} EVENTS ·{" "}
                  {fmtMassKg(stats.trackedMassKg)}
                </span>
                <UtcClock />
              </div>
            </div>
          </header>

          <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-8 pb-24">
            {children}
          </main>

          <footer className="no-print rule-t bg-[#0a0c0e]">
            <div className="mx-auto grid max-w-[1400px] gap-3 px-4 py-5 md:grid-cols-[1fr_auto]">
              <p className="max-w-3xl text-[12.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
                MatterPassport is an exhibition prototype for a physics and
                sustainability research display. This instance holds{" "}
                {stats.materialCount} material records across{" "}
                {stats.buildingCount} buildings and {stats.eventCount} logged
                events ({fmtMassKg(stats.trackedMassKg)} of declared matter).
                Every figure rendered in this interface is computed from that
                dataset at request time. Anywhere the exhibit describes
                deployment at a larger scale, it is stated in prose and marked
                as illustrative.
              </p>
              <p className="mono text-[10px] leading-relaxed tracking-[0.1em] text-[color:var(--color-ink-faint)] md:text-right">
                NO SENSORS · NO CLASSIFICATION · NO CONFIDENCE SCORING
                <br />
                DECLARED DATA + LOGGED CUSTODY ONLY
                <br />
                CARRIER: QR (CURRENT) · AGNOSTIC BY DESIGN
              </p>
            </div>
          </footer>

          <PresentationMode />
        </div>
      </body>
    </html>
  );
}
