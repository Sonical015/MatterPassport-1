import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { asc, eq, or } from "drizzle-orm";
import { materials as materialsTable } from "@/db/schema";
import { getBuilding, getBuildingInventory } from "@/lib/data";
import { ensureSeeded } from "@/db/seed";
import { fmtMassKg, STATE_SHORT, type LifecycleState } from "@/lib/lifecycle";
import { FailureState, Panel, PathwayTag, SpecRow, StateChip } from "@/components/ui";
import { BuildingSchematic } from "@/components/building-schematic";

export const dynamic = "force-dynamic";

export default async function BuildingPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const building = await getBuilding(id);
  if (!building) notFound();

  const { items, requirements } = await getBuildingInventory(building.id);
  const released = await db
    .select()
    .from(materialsTable)
    .where(
      or(
        eq(materialsTable.recoveredFromBuildingId, building.id),
        eq(materialsTable.buildingId, building.id),
      ),
    )
    .orderBy(asc(materialsTable.id));

  const vacated = released.filter(
    (m) => m.recoveredFromBuildingId === building.id && m.buildingId !== building.id,
  );

  const byClass = new Map<string, { count: number; mass: number }>();
  for (const m of items) {
    const entry = byClass.get(m.materialClass) ?? { count: 0, mass: 0 };
    entry.count += 1;
    entry.mass += m.massKg;
    byClass.set(m.materialClass, entry);
  }
  const totalMass = items.reduce((s, m) => s + m.massKg, 0);
  const classesOrder = [...byClass.entries()].sort((a, b) => b[1].mass - a[1].mass);

  return (
    <div className="grid gap-5">
      <div className="mono flex flex-wrap items-center gap-2 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)] uppercase">
        <Link href="/" className="hover:text-[color:var(--color-ink)]">
          Registry
        </Link>
        <span>/</span>
        <span className="text-[color:var(--color-ink)]">{building.code}</span>
        <span className="ml-auto">
          BUILDING RECORD · {items.length} IDENTITIES REGISTERED
        </span>
      </div>

      <section className="hair grid lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="rule-b border-b lg:border-b-0 lg:border-r">
          <BuildingSchematic
            building={building}
            current={items}
            vacated={vacated}
          />
        </div>
        <div className="grid content-start">
          <div className="rule-b bg-[#0f1215] px-3 py-2">
            <h2 className="label !text-[color:var(--color-ink-dim)]">
              Building record
            </h2>
          </div>
          <SpecRow label="Building code" value={building.code} />
          <SpecRow label="Name" value={building.name} mono={false} />
          <SpecRow label="Location" value={building.city} />
          <SpecRow
            label="Status"
            value={building.status.replace(/_/g, " ").toUpperCase()}
          />
          <SpecRow label="Floors" value={`${building.floors}`} />
          <SpecRow label="Structural system" value={building.structuralSystem} mono={false} />
          <SpecRow label="Commissioned" value={building.commissionedAt} />
          <SpecRow label="Identities registered" value={`${items.length}`} />
          <SpecRow label="Declared mass" value={fmtMassKg(totalMass)} />
          <SpecRow label="Identities released" value={`${vacated.length}`} />
          <div className="rule-t bg-[#0a0c0e] px-3 py-3">
            <p className="text-[12.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
              {building.note}
            </p>
          </div>
          <div className="rule-t flex flex-wrap gap-2 bg-[#0a0c0e] px-3 py-3">
            <Link href={`/deconstruct/${building.code}`} className="btn btn-primary">
              ▸ Deconstruction sequence
            </Link>
            <Link href="/ledger" className="btn">
              Ledger
            </Link>
          </div>
        </div>
      </section>

      {/* registered components */}
      <Panel
        title={`Registered components · ${items.length}`}
        code={`${building.code}`}
        right={
          <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
            MASS BY CLASS COMPUTED FROM THESE ROWS
          </span>
        }
      >
        {items.length === 0 ? (
          <div className="px-4 py-5">
            <FailureState
              code={`${building.code} · ${vacated.length} RELEASED`}
              title="NO COMPONENTS REGISTERED TO THIS BUILDING"
              lines={[
                `Every identity registered to ${building.code} has been released to the recovery store. The schematic above shows their vacated positions.`,
                "A building record with no components is not empty matter — it is matter whose custody has moved elsewhere while the building record remains.",
                "Reset the exhibit dataset to restore the building to its documented state.",
              ]}
              action={
                <Link href={`/deconstruct/${building.code}`} className="btn">
                  ▸ View the recovery report
                </Link>
              }
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Identity</th>
                  <th>Declared name</th>
                  <th>Class</th>
                  <th>Location reference</th>
                  <th className="text-right">Declared mass</th>
                  <th>Cond.</th>
                  <th>Pathway</th>
                  <th>State</th>
                </tr>
              </thead>
              <tbody>
                {items.map((m) => (
                  <tr key={m.id}>
                    <td>
                      <Link
                        href={`/material/${m.code}`}
                        className="text-[color:var(--color-ink)] hover:text-white hover:underline"
                      >
                        <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                        {m.code}
                      </Link>
                    </td>
                    <td className="max-w-[280px] text-[color:var(--color-ink-dim)]">
                      {m.name}
                    </td>
                    <td>{m.materialClass.toUpperCase()}</td>
                    <td className="whitespace-nowrap text-[color:var(--color-ink-dim)]">
                      {m.locationRef}
                    </td>
                    <td className="text-right">{m.massKg.toFixed(1)} kg</td>
                    <td>{m.condition}</td>
                    <td className="whitespace-nowrap">
                      <PathwayTag pathway={m.recommendedPathway} />
                    </td>
                    <td className="whitespace-nowrap text-[color:var(--color-ink-dim)]">
                      {STATE_SHORT[m.state as LifecycleState] ?? m.state}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {/* mass inventory */}
      <Panel
        title="Material inventory · declared mass by class"
        code={`${items.length} COMPONENTS`}
        footer="Derived only from the components registered to this building record at the time this page was rendered. Nothing is inferred from floor area, building type or any other source."
      >
        {items.length === 0 ? (
          <p className="mono px-4 py-5 text-[12px] text-[color:var(--color-ink-faint)]">
            NO REGISTERED COMPONENTS · INVENTORY TOTAL 0.0 kg
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Material class</th>
                  <th className="text-right">Components</th>
                  <th className="text-right">Declared mass</th>
                  <th className="text-right">Share of registered mass</th>
                  <th className="w-[34%]">Distribution</th>
                </tr>
              </thead>
              <tbody>
                {classesOrder.map(([cls, v]) => {
                  const share = totalMass > 0 ? (v.mass / totalMass) * 100 : 0;
                  return (
                    <tr key={cls}>
                      <td>{cls.toUpperCase()}</td>
                      <td className="text-right">{v.count}</td>
                      <td className="text-right">{fmtMassKg(v.mass)}</td>
                      <td className="text-right">{share.toFixed(1)}%</td>
                      <td>
                        <span className="flex h-[10px] w-full items-center">
                          <span
                            className="h-[6px]"
                            style={{
                              width: `${share}%`,
                              background: "var(--color-accent-dim)",
                            }}
                          />
                        </span>
                      </td>
                    </tr>
                  );
                })}
                <tr>
                  <td className="text-[color:var(--color-ink)]">TOTAL · REGISTERED</td>
                  <td className="text-right text-[color:var(--color-ink)]">{items.length}</td>
                  <td className="text-right text-[color:var(--color-ink)]">
                    {fmtMassKg(totalMass)}
                  </td>
                  <td className="text-right text-[color:var(--color-ink)]">100.0%</td>
                  <td />
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {/* open requirements (only buildings that hold them) */}
      {requirements.length > 0 ? (
        <Panel
          title={`Open material requirements · ${requirements.length}`}
          code={`${building.code}`}
          right={
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
              BASIS OF SECOND-LIFE MATCHING
            </span>
          }
          footer="A requirement is a demand for matter with a class, a declared specification, a required mass and a minimum recorded condition. Matching fills these rows and nothing else."
        >
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Req.</th>
                  <th>Class</th>
                  <th>Specification</th>
                  <th className="text-right">Mass required</th>
                  <th>Min cond.</th>
                  <th>Status</th>
                  <th>Filled by</th>
                </tr>
              </thead>
              <tbody>
                {requirements.map((r) => {
                  const filled = r.filledByMaterialId
                    ? released.find((m) => m.id === r.filledByMaterialId)
                    : null;
                  return (
                    <tr key={r.id}>
                      <td className="text-[color:var(--color-ink)]">{r.code}</td>
                      <td>{r.materialClass.toUpperCase()}</td>
                      <td className="max-w-[260px] text-[color:var(--color-ink-dim)]">
                        {r.spec}
                      </td>
                      <td className="text-right">{r.massRequiredKg.toFixed(1)} kg</td>
                      <td>{r.minCondition}</td>
                      <td
                        style={{
                          color:
                            r.status === "filled"
                              ? "var(--color-accent)"
                              : "var(--color-ink-dim)",
                        }}
                      >
                        {r.status === "filled" ? "● FILLED" : "○ OPEN"}
                      </td>
                      <td>
                        {filled ? (
                          <Link
                            href={`/material/${filled.code}`}
                            className="text-[color:var(--color-ink)] hover:underline"
                          >
                            <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                            {filled.code}
                          </Link>
                        ) : (
                          <span className="text-[color:var(--color-ink-faint)]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Panel>
      ) : null}

      {/* released identities */}
      {vacated.length > 0 ? (
        <Panel
          title={`Identities released from this building · ${vacated.length}`}
          code={`${building.code}`}
          footer="These records retain this building as their origin. Their custody has moved to the recovery store or to another building."
        >
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Identity</th>
                  <th>Declared name</th>
                  <th>Class</th>
                  <th className="text-right">Declared mass</th>
                  <th>Outcome</th>
                  <th>Current custody</th>
                  <th>State</th>
                </tr>
              </thead>
              <tbody>
                {vacated.map((m) => (
                  <tr key={m.id}>
                    <td>
                      <Link
                        href={`/material/${m.code}`}
                        className="text-[color:var(--color-ink-dim)] hover:text-white hover:underline"
                      >
                        <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                        {m.code}
                      </Link>
                    </td>
                    <td className="max-w-[240px] text-[color:var(--color-ink-dim)]">
                      {m.name}
                    </td>
                    <td>{m.materialClass.toUpperCase()}</td>
                    <td className="text-right">{m.massKg.toFixed(1)} kg</td>
                    <td className="whitespace-nowrap">
                      <PathwayTag pathway={m.recoveryOutcome ?? m.recommendedPathway} />
                    </td>
                    <td className="whitespace-nowrap text-[color:var(--color-ink-dim)]">
                      {m.locationRef}
                    </td>
                    <td>
                      <StateChip state={m.state} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      ) : null}
    </div>
  );
}
