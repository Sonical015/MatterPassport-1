import Link from "next/link";
import { notFound } from "next/navigation";
import { getPassport } from "@/lib/data";
import { getOrigin, matterMarkPayload, renderMatterMark } from "@/lib/qr";
import { fmtStamp } from "@/lib/lifecycle";
import { PrintablePassport } from "@/components/printable-passport";
import { PrintButton } from "@/components/print-button";

export const dynamic = "force-dynamic";

export default async function PrintPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const passport = await getPassport(id);
  if (!passport) notFound();

  const origin = await getOrigin();
  const mark = await renderMatterMark(
    matterMarkPayload(passport.material.code, origin),
  );

  return (
    <div className="grid gap-5">
      <div className="no-print mono flex flex-wrap items-center gap-2 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)] uppercase">
        <Link
          href={`/material/${passport.material.code}`}
          className="hover:text-[color:var(--color-ink)]"
        >
          ← Back to passport
        </Link>
        <span className="ml-auto">
          EVIDENCE TAG · SINGLE PAGE · {passport.material.code}
        </span>
      </div>

      <div className="no-print hair grid gap-3 px-4 py-4 md:grid-cols-[1fr_auto]">
        <div className="grid gap-2">
          <span className="label">Purpose of this document</span>
          <p className="max-w-2xl text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
            Print this and hold it beside the physical model piece that carries
            the same identity. The document is an extract of the registry
            record: declared values, custody stations and the event ledger for{" "}
            <span className="mono text-[color:var(--color-ink)]">
              {passport.material.code}
            </span>
            . It prints on one A4 page.
          </p>
        </div>
        <div className="flex items-start gap-2">
          <PrintButton label="⎙ Print / save as PDF" />
        </div>
      </div>

      <PrintablePassport
        material={passport.material}
        events={passport.events}
        building={passport.building}
        originBuilding={passport.originBuilding}
        matterMarkSvg={mark}
        printedAt={fmtStamp(new Date().toISOString())}
      />
    </div>
  );
}
