import Link from "next/link";
import { notFound } from "next/navigation";
import { getOrigin, matterMarkPayload, renderMatterMark } from "@/lib/qr";
import { getPassport } from "@/lib/data";
import {
  CONDITION_NOTE,
  fmtMassKg,
  fmtStamp,
  PATHWAYS,
  STATE_NOTE,
  STATE_ORDER,
  STATE_SHORT,
  type LifecycleState,
} from "@/lib/lifecycle";
import {
  ConditionTag,
  FailureState,
  IdTag,
  LifecycleTrack,
  Note,
  Panel,
  PathwayLegend,
  PathwayTag,
  SpecRow,
  StateChip,
} from "@/components/ui";
import { PassportTabs } from "@/components/passport-tabs";
import { MatchConsole } from "@/components/match-console";
import { PrintButton } from "@/components/print-button";
import { PrintablePassport } from "@/components/printable-passport";

export const dynamic = "force-dynamic";

const ASSESSMENT_RULE = [
  "IF the declared recovery assessment is UNRECOVERABLE → UNRECOVERABLE.",
  "ELSE IF the recorded condition is A or B → the declared assessment stands.",
  "ELSE IF the recorded condition is C → a declared REUSE is downgraded: to REPURPOSE for mass-bearing classes, to RECYCLE for glass.",
  "A declared REPURPOSE or RECYCLE stands at any recorded condition.",
];

export default async function MaterialPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ registered?: string; match?: string }>;
}) {
  const { id } = await params;
  const { registered, match } = await searchParams;
  const passport = await getPassport(id);
  if (!passport) notFound();

  const { material, events, building, originBuilding } = passport;
  const origin = await getOrigin();
  const mark = await renderMatterMark(
    matterMarkPayload(material.code, origin),
  );
  const firstRegistration = events.find((e) => e.type === "REGISTERED");
  const lastEvent = events[events.length - 1];
  const stateKey = material.state as LifecycleState;
  const terminal =
    material.state === "recycled"
      ? STATE_SHORT.recycled
      : material.state === "repurposed"
        ? STATE_SHORT.repurposed
        : material.state === "unrecoverable"
          ? STATE_SHORT.unrecoverable
          : null;
  const pathway = PATHWAYS.find((p) => p.key === material.recommendedPathway);
  const custodySites = events.map((e) => e.site);

  return (
    <>
      <div className="no-print grid gap-5">
        {/* breadcrumb */}
        <div className="mono flex flex-wrap items-center gap-2 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)] uppercase">
          <Link href="/" className="hover:text-[color:var(--color-ink)]">
            Registry
          </Link>
          <span>/</span>
          <Link href="/ledger" className="hover:text-[color:var(--color-ink)]">
            Materials
          </Link>
          <span>/</span>
          <span className="text-[color:var(--color-ink)]">{material.code}</span>
          <span className="ml-auto">
            RECORD RESOLVED · {events.length} EVENTS ON FILE
          </span>
        </div>

        {registered ? (
          <div className="hair bg-[#0d1009] px-3 py-2">
            <span className="mono text-[11px] tracking-[0.14em] text-[color:var(--color-accent)]">
              RECORD CREATED · {material.code} · IDENTITY BOUND TO THE DECLARED
              SPECIFICATION SET ABOVE
            </span>
          </div>
        ) : null}

        {/* header */}
        <section className="hair grid lg:grid-cols-[minmax(0,1fr)_300px]">
          <div className="rule-b grid gap-4 border-b lg:border-b-0 lg:border-r">
            <div className="grid gap-3 px-4 pt-4">
              <IdTag code={material.code} size="lg" />
              <h1 className="max-w-2xl text-[24px] leading-tight text-[color:var(--color-ink)]">
                {material.name}
              </h1>
              <div className="flex flex-wrap items-center gap-2">
                <StateChip state={material.state} />
                <ConditionTag condition={material.condition} />
                <PathwayTag pathway={material.recommendedPathway} />
                <span className="mono border border-[color:var(--color-hairline)] px-2 py-[3px] text-[10px] tracking-[0.14em] text-[color:var(--color-ink-dim)] uppercase">
                  {material.materialClass} · {material.componentType}
                </span>
              </div>
              <p className="max-w-2xl text-[13.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
                {STATE_NOTE[stateKey]}
              </p>
            </div>
            <dl className="mono grid grid-cols-2 gap-x-6 gap-y-3 px-4 pb-4 text-[11px] sm:grid-cols-4">
              {[
                ["Declared mass", fmtMassKg(material.massKg)],
                ["Current custody", building ? building.code : "NONE · NOT IN A BUILDING"],
                ["Location reference", material.locationRef],
                ["Last logged event", lastEvent ? fmtStamp(lastEvent.occurredAt) : "—"],
              ].map(([k, v]) => (
                <div key={k} className="min-w-0">
                  <dt className="label">{k}</dt>
                  <dd className="truncate text-[color:var(--color-ink)]" title={v}>
                    {v}
                  </dd>
                </div>
              ))}
            </dl>
            <div className="rule-t flex flex-wrap items-center gap-2 bg-[#0a0c0e] px-4 py-2">
              <Link
                href={building ? `/building/${building.code}` : "/ledger"}
                className="btn"
              >
                {building ? "▸ Locate in building" : "▸ Search the ledger"}
              </Link>
              <Link
                href={`/compare?a=${material.code}`}
                className="btn"
              >
                ⌖ Compare
              </Link>
              <Link href={`/material/${material.code}/print`} className="btn">
                ▸ Evidence tag
              </Link>
              <PrintButton label="⎙ Print this passport" />
            </div>
          </div>

          {/* MatterMark */}
          <div className="grid content-start">
            <div className="rule-b bg-[#0f1215] px-3 py-2">
              <h2 className="label !text-[color:var(--color-ink-dim)]">
                MatterMark
              </h2>
            </div>
            <div className="grid gap-3 px-4 py-4">
              <div
                className="hair grid aspect-square place-items-center bg-[#08090a] p-3"
                aria-label={`MatterMark for ${material.code}`}
                dangerouslySetInnerHTML={{ __html: mark }}
              />
              <div className="mono grid gap-1 text-[10px] leading-relaxed tracking-[0.1em] text-[color:var(--color-ink-faint)]">
                <span>CARRIER · QR (CURRENT IMPLEMENTATION)</span>
                <span>PAYLOAD · {matterMarkPayload(material.code, origin).replace(/^https?:\/\//, "")}</span>
                <span>IDENTITY LAYER · CARRIER-AGNOSTIC</span>
              </div>
              <Note>
                The mark is a carrier, not the identity. RFID, NFC, a
                laser-etched string or an optical mark would resolve this same
                record.
              </Note>
            </div>
          </div>
        </section>

        {/* lifecycle */}
        <Panel
          title="Lifecycle · logged sequence"
          code={`${events.length} EVENTS`}
          right={
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
              {STATE_ORDER.map((s) => STATE_SHORT[s]).join(" › ")}
            </span>
          }
          footer="Stages are marked from logged events only. A stage with no event is not reached, not assumed."
        >
          <div className="px-2 py-2">
            <LifecycleTrack state={material.state} terminal={terminal} />
          </div>
        </Panel>

        {/* provenance strip */}
        <Panel
          title="Provenance · chain of custody"
          code={`${custodySites.length} STATIONS`}
          right={
            originBuilding ? (
              <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                ORIGIN {originBuilding.code}
              </span>
            ) : null
          }
          footer="Stations are the site field of each logged event, in sequence. Gaps are gaps in the record, not in the matter."
        >
          <div className="overflow-x-auto px-3 py-4">
            <ol className="mono flex min-w-max items-stretch gap-2 text-[10.5px]">
              {custodySites.map((site, i) => {
                const isLast = i === custodySites.length - 1;
                return (
                  <li key={`${site}-${i}`} className="flex items-stretch gap-2">
                    <div
                      className="grid min-w-[150px] content-between border px-2 py-[6px]"
                      style={{
                        borderColor: isLast
                          ? "var(--color-accent-dim)"
                          : "var(--color-hairline)",
                      }}
                    >
                      <span
                        style={{
                          color: isLast
                            ? "var(--color-accent)"
                            : "var(--color-ink-dim)",
                        }}
                        className="leading-tight"
                      >
                        {site}
                      </span>
                      <span className="mt-1 text-[9px] tracking-[0.12em] text-[color:var(--color-ink-faint)]">
                        {events[i].type} · {fmtStamp(events[i].occurredAt).slice(0, 10)}
                      </span>
                    </div>
                    {!isLast ? (
                      <span className="self-center text-[color:var(--color-accent-dim)]">
                        →
                      </span>
                    ) : null}
                  </li>
                );
              })}
            </ol>
          </div>
        </Panel>

        {/* tabs */}
        <PassportTabs code={material.code}>
          {{
            identity: (
              <div className="grid gap-0">
                <SpecRow label="Identity string" value={material.code} />
                <SpecRow
                  label="Registry node"
                  value="MatterPassport · NL-01 (this exhibit)"
                />
                <SpecRow
                  label="Identity issued"
                  value={
                    firstRegistration
                      ? `${fmtStamp(firstRegistration.occurredAt)} · ${firstRegistration.actor}`
                      : "NOT ISSUED"
                  }
                />
                <SpecRow label="Declarant" value={material.manufacturer} />
                <SpecRow
                  label="Manufacture"
                  value={`${material.manufactureSite} · ${material.manufacturedAt}`}
                />
                <SpecRow label="Batch reference" value={material.batchRef} />
                <SpecRow
                  label="Carrier"
                  value="QR · current MatterMark implementation · carrier-agnostic identity layer"
                />
                <SpecRow
                  label="Building of origin"
                  value={
                    originBuilding
                      ? `${originBuilding.code} · ${originBuilding.name} · ${originBuilding.city}`
                      : "—"
                  }
                />
                <SpecRow
                  label="Current custody"
                  value={
                    building
                      ? `${building.code} · ${building.name} · ${building.city}`
                      : "Not held in a building record"
                  }
                />
                <SpecRow label="Events on file" value={`${events.length}`} />
                <SpecRow
                  label="Second life note"
                  value={material.secondLifeNote ?? "—"}
                />
                <div className="bg-[#0a0c0e] px-3 py-3">
                  <Note>
                    The record is append-only. Registration is the only write
                    that changes a declared value; everything afterwards is an
                    event with an actor, a site and a timestamp.
                  </Note>
                </div>
              </div>
            ),

            physical: (
              <div className="grid gap-0">
                <div className="rule-b bg-[#0d1009] px-3 py-2">
                  <span className="mono text-[10.5px] tracking-[0.16em] text-[color:var(--color-accent)]">
                    MANUFACTURER-DECLARED SPECIFICATION · NOT SENSED · NOT
                    MEASURED BY THIS SYSTEM
                  </span>
                </div>
                <SpecRow label="Declared mass" value={fmtMassKg(material.massKg)} />
                <SpecRow label="Declared dimensions" value={material.dimensions} />
                <SpecRow label="Material class" value={material.materialClass.toUpperCase()} />
                <SpecRow label="Component type" value={material.componentType.toUpperCase()} />
                <SpecRow
                  label="Recorded condition"
                  value={`${material.condition} · ${CONDITION_NOTE[material.condition] ?? ""}`}
                />
                {Object.entries(material.declaredSpecs ?? {}).map(([k, v]) => (
                  <SpecRow key={k} label={k} value={v} />
                ))}
                <div className="grid gap-3 bg-[#0a0c0e] px-3 py-3">
                  <Note>
                    Every value on this tab was declared by the manufacturer or
                    registrant and stored as a declaration. This project has no
                    sensors, no classification and no inference; nothing here
                    should be read as a measurement of the physical object.
                  </Note>
                  <Note>
                    Condition is the recorded outcome of an inspection by a
                    named surveyor, attached to the identity as an event.
                  </Note>
                </div>
              </div>
            ),

            history: (
              <div className="grid gap-0">
                <div className="overflow-x-auto">
                  <table className="ledger">
                    <thead>
                      <tr>
                        <th>Seq</th>
                        <th>Event</th>
                        <th>Timestamp (UTC)</th>
                        <th>Actor</th>
                        <th>Site</th>
                        <th>Entry</th>
                      </tr>
                    </thead>
                    <tbody>
                      {events.map((e) => (
                        <tr key={e.id}>
                          <td className="text-[color:var(--color-ink-faint)]">
                            {String(e.seq).padStart(2, "0")}
                          </td>
                          <td className="whitespace-nowrap text-[color:var(--color-ink)]">
                            {e.type}
                            <span className="ml-2 text-[color:var(--color-ink-faint)]">
                              {e.label}
                            </span>
                          </td>
                          <td className="whitespace-nowrap">
                            {fmtStamp(e.occurredAt)}
                          </td>
                          <td className="max-w-[200px] text-[color:var(--color-ink-dim)]">
                            {e.actor}
                          </td>
                          <td className="max-w-[180px] text-[color:var(--color-ink-dim)]">
                            {e.site}
                          </td>
                          <td className="max-w-[420px] text-[color:var(--color-ink-dim)]">
                            {e.detail}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="rule-t bg-[#0a0c0e] px-3 py-3">
                  <Note>
                    These {events.length} entries are the only facts of record
                    for this identity. Where an event is absent, the registry
                    holds no knowledge — it does not interpolate, and it does
                    not guess.
                  </Note>
                </div>
              </div>
            ),

            future: (
              <div className="grid gap-0">
                <div className="grid gap-4 px-4 py-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,380px)]">
                  <div className="grid content-start gap-3">
                    <div className="grid gap-2">
                      <span className="label">Assessed recovery pathway</span>
                      <div className="flex flex-wrap items-center gap-2">
                        <PathwayTag pathway={material.recommendedPathway} />
                        {material.recoveryOutcome ? (
                          <span className="mono border border-[color:var(--color-accent-dim)] px-2 py-[3px] text-[10px] tracking-[0.14em] text-[color:var(--color-accent)]">
                            OUTCOME · {material.recoveryOutcome.toUpperCase()}
                          </span>
                        ) : (
                          <span className="mono border border-[color:var(--color-hairline)] px-2 py-[3px] text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                            NOT YET ASSESSED · ASSESSMENT RUNS AT DECONSTRUCTION
                          </span>
                        )}
                      </div>
                      <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
                        {pathway?.definition}
                      </p>
                    </div>

                    <div className="grid gap-2">
                      <span className="label">Assessment rule, applied verbatim</span>
                      <ol className="mono grid gap-1 text-[11px] leading-relaxed text-[color:var(--color-ink-dim)]">
                        {ASSESSMENT_RULE.map((line) => (
                          <li key={line}>{line}</li>
                        ))}
                      </ol>
                    </div>

                    <PathwayLegend />
                  </div>

                  <div className="grid content-start gap-3">
                    <span className="label">Pathway definitions of record</span>
                    <Note>
                      The pathway is an assessment against a written rule, not a
                      prediction. When this building is deconstructed, the same
                      rule is applied to every registered component and the
                      resulting counts are what the recovery report shows.
                    </Note>
                    {building ? (
                      <Link
                        href={`/deconstruct/${building.code}`}
                        className="btn"
                      >
                        ▸ Run deconstruction on {building.code}
                      </Link>
                    ) : null}
                  </div>
                </div>

                <div className="rule-t bg-[#0f1215] px-3 py-2">
                  <h3 className="label !text-[color:var(--color-ink-dim)]">
                    Second life · match against open requirements
                  </h3>
                </div>
                <MatchConsole code={material.code} auto={match === "1"} />
              </div>
            ),
          }}
        </PassportTabs>
      </div>

      {/* printable evidence tag */}
      <div className="print-only pt-4">
        <PrintablePassport
          material={material}
          events={events}
          building={building}
          originBuilding={originBuilding}
          matterMarkSvg={mark}
          printedAt={fmtStamp(new Date().toISOString())}
        />
      </div>
    </>
  );
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const passport = await getPassport(id);
  if (!passport) return { title: "Material not found · MatterPassport" };
  return {
    title: `${passport.material.code} · ${passport.material.name} · MatterPassport`,
  };
}
