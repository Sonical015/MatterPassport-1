import Link from "next/link";
import {
  getDatasetStats,
  listBuildings,
  listEvents,
  listMaterials,
} from "@/lib/data";
import { fmtMassKg, fmtStamp, STATE_SHORT, type LifecycleState } from "@/lib/lifecycle";
import { Panel, SectionTitle, SpecRow, StateChip } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function LedgerPage() {
  const [materials, buildings, events, stats] = await Promise.all([
    listMaterials(),
    listBuildings(),
    listEvents(),
    getDatasetStats(),
  ]);

  const buildingById = new Map(buildings.map((b) => [b.id, b]));
  const materialById = new Map(materials.map((m) => [m.id, m]));
  const recent = [...events]
    .sort((a, b) => (a.occurredAt < b.occurredAt ? 1 : -1))
    .slice(0, 24);
  const byClass = new Map<string, { count: number; mass: number }>();
  for (const m of materials) {
    const e = byClass.get(m.materialClass) ?? { count: 0, mass: 0 };
    e.count += 1;
    e.mass += m.massKg;
    byClass.set(m.materialClass, e);
  }

  return (
    <div className="grid gap-5">
      <SectionTitle
        index="/ LEDGER"
        title="Registry ledger"
        note={`The complete contents of this node: ${stats.materialCount} material identities, ${stats.buildingCount} building records and ${stats.eventCount} logged events. This is not a sample of a larger dataset — it is the dataset.`}
      />

      <section className="hair grid md:grid-cols-4">
        {[
          ["Material identities", `${stats.materialCount}`],
          ["Building records", `${stats.buildingCount}`],
          ["Logged events", `${stats.eventCount}`],
          ["Declared mass", fmtMassKg(stats.trackedMassKg)],
        ].map(([k, v], i) => (
          <div
            key={k}
            className={`grid content-between gap-2 px-3 py-3 ${
              i < 3 ? "rule-b border-b md:border-b-0 md:border-r" : ""
            }`}
          >
            <span className="label">{k}</span>
            <span className="mono text-[17px] text-[color:var(--color-ink)]">{v}</span>
          </div>
        ))}
      </section>

      <Panel
        title={`Material identities · ${materials.length}`}
        code="ALL RECORDS"
        right={
          <Link
            href="/compare"
            className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-accent)] underline uppercase"
          >
            Compare two ▸
          </Link>
        }
      >
        <div className="overflow-x-auto">
          <table className="ledger">
            <thead>
              <tr>
                <th>Identity</th>
                <th>Declared name</th>
                <th>Class</th>
                <th className="text-right">Declared mass</th>
                <th>Cond.</th>
                <th>State</th>
                <th>Custody</th>
                <th>Origin</th>
                <th>Pathway</th>
              </tr>
            </thead>
            <tbody>
              {materials.map((m) => (
                <tr key={m.id}>
                  <td>
                    <Link
                      href={`/material/${m.code}`}
                      className="text-[color:var(--color-ink)] hover:text-white hover:underline"
                    >
                      <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                      {m.code}
                    </Link>
                  </td>
                  <td className="max-w-[260px] text-[color:var(--color-ink-dim)]">
                    {m.name}
                  </td>
                  <td>{m.materialClass.toUpperCase()}</td>
                  <td className="text-right">{m.massKg.toFixed(1)} kg</td>
                  <td>{m.condition}</td>
                  <td className="whitespace-nowrap text-[color:var(--color-ink-dim)]">
                    {STATE_SHORT[m.state as LifecycleState] ?? m.state}
                  </td>
                  <td className="whitespace-nowrap text-[color:var(--color-ink-dim)]">
                    {m.buildingId
                      ? (buildingById.get(m.buildingId)?.code ?? "—")
                      : m.locationRef}
                  </td>
                  <td className="whitespace-nowrap text-[color:var(--color-ink-faint)]">
                    {m.originBuildingId
                      ? (buildingById.get(m.originBuildingId)?.code ?? "—")
                      : "—"}
                  </td>
                  <td className="whitespace-nowrap text-[color:var(--color-ink-faint)]">
                    {(m.recoveryOutcome ?? m.recommendedPathway).toUpperCase()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title={`Buildings · ${buildings.length}`} code="ALL RECORDS">
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Status</th>
                  <th className="text-right">Identities</th>
                  <th className="text-right">Declared mass</th>
                </tr>
              </thead>
              <tbody>
                {buildings.map((b) => {
                  const items = materials.filter((m) => m.buildingId === b.id);
                  return (
                    <tr key={b.id}>
                      <td>
                        <Link
                          href={`/building/${b.code}`}
                          className="text-[color:var(--color-ink)] hover:underline"
                        >
                          {b.code}
                        </Link>
                      </td>
                      <td className="text-[color:var(--color-ink-dim)]">{b.name}</td>
                      <td className="whitespace-nowrap text-[color:var(--color-ink-dim)]">
                        {b.status.replace(/_/g, " ").toUpperCase()}
                      </td>
                      <td className="text-right">{items.length}</td>
                      <td className="text-right">
                        {fmtMassKg(items.reduce((s, m) => s + m.massKg, 0))}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel title="Declared mass by class" code="ALL RECORDS">
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Class</th>
                  <th className="text-right">Identities</th>
                  <th className="text-right">Declared mass</th>
                  <th className="text-right">Share</th>
                </tr>
              </thead>
              <tbody>
                {[...byClass.entries()]
                  .sort((a, b) => b[1].mass - a[1].mass)
                  .map(([cls, v]) => (
                    <tr key={cls}>
                      <td>{cls.toUpperCase()}</td>
                      <td className="text-right">{v.count}</td>
                      <td className="text-right">{fmtMassKg(v.mass)}</td>
                      <td className="text-right">
                        {((v.mass / stats.trackedMassKg) * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>

      <Panel
        title={`Event stream · most recent ${recent.length} of ${events.length}`}
        code="APPEND-ONLY"
        footer="Events are the only mechanism by which this registry learns anything. There is no sensor feed, no batch import and no inference."
      >
        <div className="overflow-x-auto">
          <table className="ledger">
            <thead>
              <tr>
                <th>Timestamp (UTC)</th>
                <th>Event</th>
                <th>Identity</th>
                <th>Actor</th>
                <th>Site</th>
                <th>Entry</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((e) => (
                <tr key={e.id}>
                  <td className="whitespace-nowrap">{fmtStamp(e.occurredAt)}</td>
                  <td className="whitespace-nowrap text-[color:var(--color-ink)]">
                    {e.type}
                  </td>
                  <td className="whitespace-nowrap">
                    <Link
                      href={`/material/${materialById.get(e.materialId)?.code ?? ""}`}
                      className="text-[color:var(--color-ink-dim)] hover:underline"
                    >
                      {materialById.get(e.materialId)?.code ?? "—"}
                    </Link>
                  </td>
                  <td className="max-w-[190px] text-[color:var(--color-ink-dim)]">
                    {e.actor}
                  </td>
                  <td className="max-w-[170px] text-[color:var(--color-ink-dim)]">
                    {e.site}
                  </td>
                  <td className="max-w-[400px] text-[color:var(--color-ink-faint)]">
                    {e.detail}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel title="Node configuration" code="NL-01">
        <SpecRow label="Node" value="NL-01 · Delft · exhibit instance" />
        <SpecRow label="Carrier in use" value="QR · error correction M" />
        <SpecRow label="Write paths" value="Registration · deconstruction · reassignment" />
        <SpecRow label="Sensing" value="NONE" />
        <SpecRow label="Classification / inference" value="NONE" />
        <SpecRow label="Scoring" value="NONE" />
        <div className="rule-b bg-[#0a0c0e] px-3 py-3">
          <StateChip state="registered" />
        </div>
      </Panel>
    </div>
  );
}
