import Link from "next/link";
import { getPassport, listMaterials } from "@/lib/data";
import { CompareCard } from "@/components/compare-card";
import { ComparePicker } from "@/components/compare-picker";
import { FailureState, Note, Panel, SectionTitle } from "@/components/ui";
import { fmtMassKg } from "@/lib/lifecycle";

export const dynamic = "force-dynamic";

export default async function ComparePage({
  searchParams,
}: {
  searchParams: Promise<{ a?: string; b?: string }>;
}) {
  const { a, b } = await searchParams;
  const materials = await listMaterials();
  const options = materials.map((m) => ({ code: m.code, name: m.name }));
  const left = a ?? "MP-000184";
  const right = b ?? "MP-000201";

  const [pa, pb] = await Promise.all([getPassport(left), getPassport(right)]);

  if (!pa || !pb) {
    return (
      <div className="grid gap-5">
        <SectionTitle
          index="/ COMPARE"
          title="Compare two identities"
          note="One of the requested identity strings does not resolve in this node."
        />
        <FailureState
          code="COMPARE · LOOKUP FAILED"
          title="ONE SPECIMEN COULD NOT BE RESOLVED"
          lines={[
            `Requested · ${left} vs ${right}`,
            "Comparison requires two identity strings that both resolve in registry node NL-01.",
            "Select two identities from the ledger and try again.",
          ]}
          action={
            <Link href="/ledger" className="btn btn-primary">
              ▸ Open the ledger
            </Link>
          }
        />
      </div>
    );
  }

  const massDiff = pa.material.massKg - pb.material.massKg;

  return (
    <div className="grid gap-5">
      <SectionTitle
        index="/ COMPARE"
        title="Compare two identities"
        note="Two passports, side by side, drawn from the same registry. Rows where the two records differ are marked. Nothing is normalised, weighted or scored."
      />

      <ComparePicker options={options} a={pa.material.code} b={pb.material.code} />

      <section className="grid gap-4 lg:grid-cols-2">
        <CompareCard
          material={pa.material}
          other={pb.material}
          events={pa.events}
          building={pa.building}
          originBuilding={pa.originBuilding}
        />
        <CompareCard
          material={pb.material}
          other={pa.material}
          events={pb.events}
          building={pb.building}
          originBuilding={pb.originBuilding}
        />
      </section>

      <Panel title="Comparison readout" code={`${pa.material.code} · ${pb.material.code}`}>
        <div className="grid gap-3 px-4 py-4 md:grid-cols-3">
          <div className="grid gap-1">
            <span className="label">Declared mass difference</span>
            <span className="mono text-[15px] text-[color:var(--color-ink)]">
              {massDiff === 0
                ? "0.0 kg · equal"
                : `${massDiff > 0 ? "+" : ""}${fmtMassKg(Math.abs(massDiff))} ${
                    massDiff > 0 ? "heavier in A" : "heavier in B"
                  }`}
            </span>
            <span className="mono text-[10px] text-[color:var(--color-ink-faint)]">
              DIFFERENCE OF TWO DECLARED VALUES · NOT A MEASUREMENT
            </span>
          </div>
          <div className="grid gap-1">
            <span className="label">Events on file</span>
            <span className="mono text-[15px] text-[color:var(--color-ink)]">
              {pa.events.length} vs {pb.events.length}
            </span>
            <span className="mono text-[10px] text-[color:var(--color-ink-faint)]">
              COUNT OF LOGGED ENTRIES PER IDENTITY
            </span>
          </div>
          <div className="grid gap-1">
            <span className="label">Classes compared</span>
            <span className="mono text-[15px] text-[color:var(--color-ink)]">
              {pa.material.materialClass.toUpperCase()} /{" "}
              {pb.material.materialClass.toUpperCase()}
            </span>
            <span className="mono text-[10px] text-[color:var(--color-ink-faint)]">
              NO COMPATIBILITY VALUE IS COMPUTED HERE
            </span>
          </div>
        </div>
        <div className="rule-t bg-[#0a0c0e] px-4 py-3">
          <Note>
            A comparison shows what is declared and what has been logged. It
            deliberately produces no compatibility figure: the only ratio this
            exhibit computes is mass coverage, and only against a requirement
            with a stated mass and condition threshold.
          </Note>
        </div>
      </Panel>
    </div>
  );
}
