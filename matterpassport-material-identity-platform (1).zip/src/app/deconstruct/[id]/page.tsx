import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { asc, eq, inArray } from "drizzle-orm";
import { materials as materialsTable } from "@/db/schema";
import { getBuilding, getRecoveryReport } from "@/lib/data";
import {
  assessPathway,
  fmtMassKg,
  fmtStamp,
  PATHWAYS,
  type PathwayKey,
} from "@/lib/lifecycle";
import { DeconstructConsole } from "@/components/deconstruct-console";
import {
  FailureState,
  Note,
  Panel,
  PathwayLegend,
  PathwayTag,
  SpecRow,
} from "@/components/ui";

export const dynamic = "force-dynamic";

const ASSESSMENT_RULE = [
  "1 · IF declared recovery assessment = UNRECOVERABLE → UNRECOVERABLE",
  "2 · ELSE IF recorded condition is A or B → declared assessment stands",
  "3 · ELSE IF recorded condition is C and declared assessment = REUSE → REPURPOSE (RECYCLE for glass)",
  "4 · A declared REPURPOSE or RECYCLE stands at any recorded condition",
];

export default async function DeconstructPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ run?: string }>;
}) {
  const { id } = await params;
  const { run } = await searchParams;
  const building = await getBuilding(id);
  if (!building) notFound();

  const report = await getRecoveryReport(building.code);
  if (!report) notFound();

  const live = await db
    .select()
    .from(materialsTable)
    .where(eq(materialsTable.buildingId, building.id))
    .orderBy(asc(materialsTable.id));
  const pending = live.filter((m) =>
    ["in_service", "repaired", "second_life"].includes(m.state),
  );
  const pendingLines = pending.map((m) => ({
    code: m.code,
    massKg: m.massKg,
    condition: m.condition,
    outcome: assessPathway({
      recommendedPathway: m.recommendedPathway,
      condition: m.condition,
      materialClass: m.materialClass,
    }),
  }));

  // Identities released from this building that have since been reassigned,
  // used to surface second-life outcomes inside the report.
  const reassigned = report.lines.filter((l) => l.material.state === "second_life");
  const openRecovery = report.lines.filter(
    (l) =>
      l.material.state === "recovered" &&
      (l.outcome === "reuse" || l.outcome === "repurpose"),
  );
  const requirementRows = reassigned.length
    ? await db
        .select()
        .from(materialsTable)
        .where(inArray(materialsTable.id, reassigned.map((r) => r.material.id)))
    : [];

  const hasReport = report.lines.length > 0;
  const maxMass = Math.max(
    ...PATHWAYS.map((p) => report.totals[p.key as PathwayKey].mass),
    1,
  );

  return (
    <div className="grid gap-5">
      <div className="mono flex flex-wrap items-center gap-2 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)] uppercase">
        <Link href="/" className="hover:text-[color:var(--color-ink)]">
          Registry
        </Link>
        <span>/</span>
        <Link
          href={`/building/${building.code}`}
          className="hover:text-[color:var(--color-ink)]"
        >
          {building.code}
        </Link>
        <span>/</span>
        <span className="text-[color:var(--color-ink)]">DECONSTRUCTION</span>
        <span className="ml-auto">
          {hasReport
            ? `REPORT ON FILE · ${report.componentCount} IDENTITIES`
            : "NO SEQUENCE RUN AGAINST THIS BUILDING"}
        </span>
      </div>

      <section className="hair grid lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="rule-b border-b lg:border-b-0 lg:border-r">
          <div className="rule-b flex items-center justify-between bg-[#0f1215] px-3 py-2">
            <h1 className="label !text-[color:var(--color-ink)]">
              Deconstruction sequence · {building.code} · {building.name}
            </h1>
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
              {building.city}
            </span>
          </div>
          {pending.length > 0 ? (
            <DeconstructConsole
              buildingCode={building.code}
              buildingName={building.name}
              lines={pendingLines}
              auto={run === "1"}
            />
          ) : (
            <div className="grid gap-3 px-4 py-5">
              <p className="mono text-[12px] leading-relaxed text-[color:var(--color-ink-dim)]">
                NO IDENTITIES REMAIN IN CUSTODY OF {building.code}.
                <br />
                THE SEQUENCE HAS BEEN RUN · THE REPORT BELOW IS THE REGISTRY
                STATE.
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                  RESET RESTORES THE DOCUMENTED DATASET
                </span>
                <ResetDataset />
              </div>
            </div>
          )}
        </div>
        <div className="grid content-start">
          <div className="rule-b bg-[#0f1215] px-3 py-2">
            <h2 className="label !text-[color:var(--color-ink-dim)]">
              Assessment rule of record
            </h2>
          </div>
          <ol className="mono grid gap-[6px] px-3 py-3 text-[11px] leading-relaxed text-[color:var(--color-ink-dim)]">
            {ASSESSMENT_RULE.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ol>
          <div className="rule-t px-3 py-3">
            <PathwayLegend />
          </div>
        </div>
      </section>

      {hasReport ? (
        <>
          {/* headline figures */}
          <section className="hair grid md:grid-cols-4">
            <div className="rule-b grid content-between gap-2 border-b px-3 py-3 md:border-b-0 md:border-r">
              <span className="label">Building</span>
              <span className="mono text-[15px] tracking-[0.1em] text-[color:var(--color-ink)]">
                {building.code}
              </span>
              <span className="mono text-[10.5px] text-[color:var(--color-ink-faint)]">
                {report.componentCount} IDENTITIES PROCESSED
              </span>
            </div>
            <div className="rule-b grid content-between gap-2 border-b px-3 py-3 md:border-b-0 md:border-r">
              <span className="label">Declared mass in scope</span>
              <span className="mono text-[15px] text-[color:var(--color-ink)]">
                {fmtMassKg(report.totalMass)}
              </span>
              <span className="mono text-[10.5px] text-[color:var(--color-ink-faint)]">
                SUM OF DECLARED MASS, REGISTERED COMPONENTS
              </span>
            </div>
            <div className="rule-b grid content-between gap-2 border-b px-3 py-3 md:border-b-0 md:border-r">
              <span className="label">Mass recovered</span>
              <span className="mono text-[15px] text-[color:var(--color-ink)]">
                {fmtMassKg(report.recoveredMass)}
              </span>
              <span className="mono text-[10.5px] text-[color:var(--color-ink-faint)]">
                EXCLUDES {fmtMassKg(report.unrecoverableMass)} ASSESSED
                UNRECOVERABLE
              </span>
            </div>
            <div className="grid content-between gap-2 px-3 py-3">
              <span className="label">Recovery rate</span>
              <span className="mono text-[26px] leading-none text-[color:var(--color-accent)]">
                {report.recoveryPct.toFixed(1)}%
              </span>
              <span className="mono text-[10.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
                (TOTAL MASS − UNRECOVERABLE MASS) ÷ TOTAL MASS × 100 ={" "}
                {fmtMassKg(report.recoveredMass)} ÷ {fmtMassKg(report.totalMass)}
              </span>
            </div>
          </section>

          {/* counts by pathway */}
          <Panel
            title="Material recovery report · counts by pathway"
            code={`${building.code}`}
            right={
              <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                COMPUTED FROM {report.componentCount} RELEASED IDENTITIES
              </span>
            }
            footer="Each row is a count of identities and a sum of declared mass. The bar shows each pathway's share of the released mass, not of a target."
          >
            <table className="ledger">
              <thead>
                <tr>
                  <th>Pathway</th>
                  <th className="text-right">Identities</th>
                  <th className="text-right">Declared mass</th>
                  <th className="text-right">Share of released mass</th>
                  <th className="w-[38%]">Mass distribution</th>
                </tr>
              </thead>
              <tbody>
                {PATHWAYS.map((p) => {
                  const t = report.totals[p.key as PathwayKey];
                  const share = report.totalMass > 0 ? (t.mass / report.totalMass) * 100 : 0;
                  return (
                    <tr key={p.key}>
                      <td>
                        <PathwayTag pathway={p.key} />
                        <span className="mt-1 block max-w-[320px] text-[11px] leading-snug text-[color:var(--color-ink-faint)]">
                          {p.definition}
                        </span>
                      </td>
                      <td className="text-right text-[color:var(--color-ink)]">
                        {t.count}
                      </td>
                      <td className="text-right">{fmtMassKg(t.mass)}</td>
                      <td className="text-right">{share.toFixed(1)}%</td>
                      <td>
                        <span className="flex h-[10px] w-full items-center">
                          <span
                            className="h-[6px]"
                            style={{
                              width: `${(t.mass / maxMass) * 100}%`,
                              background:
                                p.key === "unrecoverable"
                                  ? "var(--color-caution)"
                                  : "var(--color-accent-dim)",
                            }}
                          />
                        </span>
                      </td>
                    </tr>
                  );
                })}
                <tr>
                  <td className="text-[color:var(--color-ink)]">TOTAL RELEASED</td>
                  <td className="text-right text-[color:var(--color-ink)]">
                    {report.componentCount}
                  </td>
                  <td className="text-right text-[color:var(--color-ink)]">
                    {fmtMassKg(report.totalMass)}
                  </td>
                  <td className="text-right text-[color:var(--color-ink)]">100.0%</td>
                  <td />
                </tr>
              </tbody>
            </table>
          </Panel>

          {/* line items */}
          <Panel
            title={`Released identities · ${report.lines.length}`}
            code={`${building.code}`}
            footer="Second-life actions are offered only where the assessed outcome retains the element. Recycling and unrecoverable identities close the record instead."
          >
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Identity</th>
                    <th>Declared name</th>
                    <th>Class</th>
                    <th className="text-right">Declared mass</th>
                    <th>Cond.</th>
                    <th>Declared assessment</th>
                    <th>Assessed outcome</th>
                    <th>Current custody</th>
                    <th>Second life</th>
                  </tr>
                </thead>
                <tbody>
                  {report.lines.map(({ material, outcome }) => {
                    const eligible = outcome === "reuse" || outcome === "repurpose";
                    return (
                      <tr key={material.id}>
                        <td>
                          <Link
                            href={`/material/${material.code}`}
                            className="text-[color:var(--color-ink)] hover:text-white hover:underline"
                          >
                            <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                            {material.code}
                          </Link>
                        </td>
                        <td className="max-w-[240px] text-[color:var(--color-ink-dim)]">
                          {material.name}
                        </td>
                        <td>{material.materialClass.toUpperCase()}</td>
                        <td className="text-right">{material.massKg.toFixed(1)} kg</td>
                        <td>{material.condition}</td>
                        <td className="whitespace-nowrap text-[color:var(--color-ink-faint)]">
                          {material.recommendedPathway.toUpperCase()}
                        </td>
                        <td
                          className="whitespace-nowrap"
                          style={{
                            color:
                              outcome === "unrecoverable"
                                ? "var(--color-caution)"
                                : "var(--color-accent)",
                          }}
                        >
                          ● {outcome.toUpperCase()}
                        </td>
                        <td className="max-w-[180px] whitespace-nowrap text-[color:var(--color-ink-dim)]">
                          {material.locationRef}
                        </td>
                        <td className="whitespace-nowrap">
                          {eligible ? (
                            <Link
                              href={`/material/${material.code}?tab=future&match=1`}
                              className="mono text-[10.5px] tracking-[0.12em] text-[color:var(--color-accent)] underline uppercase"
                            >
                              ▸ Find a second life
                            </Link>
                          ) : material.state === "second_life" ? (
                            <span className="mono text-[10.5px] tracking-[0.12em] text-[color:var(--color-ink-dim)] uppercase">
                              ● Assigned
                            </span>
                          ) : (
                            <span className="mono text-[10.5px] tracking-[0.12em] text-[color:var(--color-ink-faint)] uppercase">
                              Record closed
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>

          {/* second life summary */}
          <Panel
            title="Second life · status of released identities"
            code={`${building.code}`}
            right={
              <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                {openRecovery.length} AVAILABLE · {reassigned.length} ASSIGNED
              </span>
            }
          >
            <div className="grid gap-3 px-4 py-4 md:grid-cols-2">
              <div className="grid gap-2">
                <span className="label">Available for reassignment</span>
                {openRecovery.length === 0 ? (
                  <p className="mono text-[11.5px] text-[color:var(--color-ink-faint)]">
                    NO ELEMENT-RETAINING IDENTITIES REMAIN UNASSIGNED
                  </p>
                ) : (
                  <ul className="grid gap-[6px]">
                    {openRecovery.map(({ material }) => (
                      <li key={material.id}>
                        <Link
                          href={`/material/${material.code}?tab=future&match=1`}
                          className="mono grid grid-cols-[auto_1fr_auto] gap-3 border border-[color:var(--color-hairline)] px-2 py-[5px] text-[11px] hover:border-[color:var(--color-accent-dim)]"
                        >
                          <span className="text-[color:var(--color-ink)]">{material.code}</span>
                          <span className="truncate text-[color:var(--color-ink-dim)]">
                            {material.name}
                          </span>
                          <span className="text-[color:var(--color-ink-faint)]">
                            {material.massKg.toFixed(1)} kg
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="grid gap-2">
                <span className="label">Assigned to another building</span>
                {reassigned.length === 0 ? (
                  <p className="mono text-[11.5px] text-[color:var(--color-ink-faint)]">
                    NONE YET · RUN A MATCH FROM THE FUTURE TAB OF ANY AVAILABLE
                    IDENTITY
                  </p>
                ) : (
                  <ul className="grid gap-[6px]">
                    {reassigned.map(({ material }) => (
                      <li
                        key={material.id}
                        className="mono grid grid-cols-[auto_1fr] gap-3 border border-[color:var(--color-accent-dim)] px-2 py-[5px] text-[11px]"
                      >
                        <Link
                          href={`/material/${material.code}`}
                          className="text-[color:var(--color-ink)] hover:underline"
                        >
                          {material.code}
                        </Link>
                        <span className="truncate text-[color:var(--color-ink-dim)]">
                          {material.locationRef}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
                {requirementRows.length > 0 ? (
                  <Note>
                    {reassigned.length} of {report.componentCount} released
                    identities have been reassigned. The remainder are held in
                    the recovery store, or their records are closed.
                  </Note>
                ) : null}
              </div>
            </div>
          </Panel>

          <Panel title="Report provenance" code={`${building.code}`}>
            <SpecRow
              label="Building record"
              value={`${building.code} · ${building.name} · ${building.city}`}
            />
            <SpecRow label="Identities processed" value={`${report.componentCount}`} />
            <SpecRow label="Events written" value={`${report.componentCount * 2}`} />
            <SpecRow
              label="Report generated"
              value={`${fmtStamp(new Date().toISOString())} · at request time`}
            />
            <SpecRow
              label="Method"
              value="Counts and masses are aggregated in the registry from the released identities of this building only. No figures are stored in advance."
              mono={false}
            />
          </Panel>
        </>
      ) : (
        <FailureState
          code={`${building.code} · NO REPORT`}
          title="NO RECOVERY REPORT ON FILE FOR THIS BUILDING"
          lines={[
            `The deconstruction sequence has not been run against ${building.code}. ${pending.length} identities are still in custody of this building record.`,
            "A report is produced only by running the sequence: there is no projected, simulated or cached version of it anywhere in this exhibit.",
            "Run the sequence above to generate one from the registered components.",
          ]}
        />
      )}
    </div>
  );
}

function ResetDataset() {
  return (
    <form
      action={async () => {
        "use server";
        const { resetDemo } = await import("@/db/seed");
        await resetDemo();
      }}
    >
      <button className="btn" type="submit">
        ↺ Reset exhibit dataset
      </button>
    </form>
  );
}
