import Link from "next/link";
import { getDatasetStats, listBuildings, listMaterials } from "@/lib/data";
import { fmtMassKg, STATE_SHORT } from "@/lib/lifecycle";
import { getOrigin, matterMarkPayload, renderMatterMark } from "@/lib/qr";
import { IdTag, Meta, Note, Panel, SectionTitle, StateChip } from "@/components/ui";

export const dynamic = "force-dynamic";

const TODAY = [
  { label: "EXTRACT", note: "Matter enters the industrial record as feedstock." },
  { label: "MANUFACTURE", note: "A product is made. Its identity is the product." },
  { label: "ASSEMBLE", note: "Components enter a building and lose their names." },
  { label: "OCCUPY", note: "Decades of use. Nothing is written down." },
  { label: "DEMOLISH", note: "Mixed, contaminated, undocumented." },
  { label: "SHRED · MELT · LANDFILL", note: "Matter continues. The record does not.", terminal: true },
];

const LIFECYCLE = [
  { label: "MANUFACTURE", note: "Declared specification issued by the maker." },
  { label: "REGISTER", note: "Identity string bound to that declaration." },
  { label: "CONSTRUCT", note: "Installed. Custody passes to a building record." },
  { label: "USE", note: "Location reference and inspection logged." },
  { label: "REPAIR", note: "Intervention recorded against the same identity." },
  { label: "DECONSTRUCT", note: "Element released whole. Identity survives the building." },
  { label: "RECOVER", note: "Assessed against a stated pathway rule." },
  { label: "SECOND LIFE", note: "Reassigned. The loop is closed by record, not by hope." },
];

function Column({
  title,
  caption,
  steps,
  tone,
}: {
  title: string;
  caption: string;
  steps: { label: string; note: string; terminal?: boolean }[];
  tone: "today" | "mp";
}) {
  return (
    <div className="hair">
      <div className="rule-b flex items-baseline justify-between bg-[#0f1215] px-3 py-2">
        <h3 className="label !text-[color:var(--color-ink)]">{title}</h3>
        <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
          {tone === "today" ? "NO PERSISTENT IDENTITY" : "IDENTITY RETAINED"}
        </span>
      </div>
      <ol className="px-3 py-3">
        {steps.map((s, i) => (
          <li key={s.label} className="relative grid grid-cols-[18px_1fr] gap-3 pb-3 last:pb-0">
            <div className="relative flex justify-center">
              {i < steps.length - 1 ? (
                <span
                  className="absolute top-[10px] h-full w-[1px]"
                  style={{
                    background:
                      s.terminal || tone === "today"
                        ? "var(--color-hairline)"
                        : "var(--color-accent-dim)",
                  }}
                />
              ) : null}
              <span
                className="relative z-10 mt-[3px] block h-[9px] w-[9px]"
                style={{
                  background: s.terminal
                    ? "var(--color-caution)"
                    : tone === "today"
                      ? "var(--color-hairline)"
                      : "var(--color-accent-dim)",
                  outline: "3px solid var(--color-panel)",
                }}
              />
            </div>
            <div className="pb-1">
              <div
                className="mono text-[11px] tracking-[0.16em]"
                style={{
                  color: s.terminal
                    ? "var(--color-caution)"
                    : tone === "today"
                      ? "var(--color-ink-dim)"
                      : "var(--color-ink)",
                }}
              >
                {s.label}
              </div>
              <p className="mt-[2px] text-[12.5px] leading-snug text-[color:var(--color-ink-faint)]">
                {s.note}
              </p>
            </div>
          </li>
        ))}
        {tone === "mp" ? (
          <li className="rule-t mt-1 pt-2">
            <span className="mono text-[10px] tracking-[0.16em] text-[color:var(--color-accent)]">
              ↺ RETURN TO CONSTRUCT · SAME IDENTITY, NEXT BUILDING
            </span>
          </li>
        ) : null}
      </ol>
      <div className="rule-t bg-[#0a0c0e] px-3 py-2 text-[12px] text-[color:var(--color-ink-faint)]">
        {caption}
      </div>
    </div>
  );
}

function FutureNetwork() {
  const nodes = [
    { x: 40, label: "FACTORY", sub: "declaration issued" },
    { x: 235, label: "MATERIAL", sub: "identity bound" },
    { x: 430, label: "BUILDING", sub: "custody" },
    { x: 625, label: "DECONSTRUCTION", sub: "release, whole" },
    { x: 820, label: "RECOVERY STORE", sub: "assessed" },
    { x: 1015, label: "NEXT BUILDING", sub: "second life" },
  ];
  return (
    <div className="overflow-x-auto px-3 py-4">
      <svg viewBox="0 0 1100 250" className="min-w-[900px]" role="img" aria-label="Future-state network diagram">
        <defs>
          <pattern id="fgrid" width="25" height="25" patternUnits="userSpaceOnUse">
            <path d="M25 0H0V25" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
          </pattern>
        </defs>
        <rect x="0" y="0" width="1100" height="250" fill="url(#fgrid)" />
        <line x1="40" y1="120" x2="1075" y2="120" stroke="#24282c" strokeWidth="1" />
        <path d="M940 120 C 1010 120 1010 200 700 200 L 235 200 C 120 200 120 120 235 120"
          fill="none" stroke="#7a5620" strokeWidth="1" strokeDasharray="5 4" />
        <text x="590" y="216" fill="#f0a33a" fontSize="10" fontFamily="monospace" letterSpacing="2">
          MATERIAL RETURNS TO SERVICE · IDENTITY PERSISTS
        </text>
        {nodes.map((n) => (
          <g key={n.label}>
            <rect x={n.x - 12} y="106" width="24" height="24" fill="#0d0f11" stroke="#3a3f44" strokeWidth="1" />
            <circle cx={n.x} cy="118" r="3" fill="#f0a33a" />
            <text x={n.x} y="86" fill="#d8dbdd" fontSize="11" fontFamily="monospace" letterSpacing="1.4" textAnchor="middle">
              {n.label}
            </text>
            <text x={n.x} y="100" fill="#61676d" fontSize="9" fontFamily="monospace" letterSpacing="1" textAnchor="middle">
              {n.sub}
            </text>
          </g>
        ))}
        <text x="40" y="30" fill="#61676d" fontSize="9.5" fontFamily="monospace" letterSpacing="1.6">
          FUTURE-STATE CONCEPT · DIAGRAMMATIC · NO LIVE DATA IN THIS PANEL
        </text>
        <text x="40" y="46" fill="#8d949a" fontSize="11" fontFamily="monospace" letterSpacing="1">
          One registry, many buildings, matter circulating under continuous identity.
        </text>
        <text x="1075" y="240" fill="#61676d" fontSize="9" fontFamily="monospace" letterSpacing="1" textAnchor="end">
          NOT TO SCALE · NOT A MEASUREMENT
        </text>
      </svg>
    </div>
  );
}

export default async function LandingPage() {
  const [stats, buildings, materials, origin] = await Promise.all([
    getDatasetStats(),
    listBuildings(),
    listMaterials(),
    getOrigin(),
  ]);
  const mark = await renderMatterMark(matterMarkPayload("MP-000184", origin));

  return (
    <div className="grid gap-12">
      {/* HERO */}
      <section className="grid gap-8 lg:grid-cols-[1.35fr_1fr]">
        <div className="grid content-start gap-6">
          <div className="flex items-center gap-3">
            <span className="mono text-[10px] tracking-[0.2em] text-[color:var(--color-accent)]">
              EXHIBIT 01
            </span>
            <span className="mono text-[10px] tracking-[0.2em] text-[color:var(--color-ink-faint)]">
              IDENTITY FOR PHYSICAL MATTER
            </span>
          </div>
          <h1 className="max-w-3xl text-[clamp(2.1rem,4.6vw,3.6rem)] leading-[1.02] text-[color:var(--color-ink)]">
            We don&apos;t track products.
            <br />
            <span className="text-[color:var(--color-accent)]">We track matter.</span>
          </h1>
          <p className="max-w-2xl text-[15.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
            A product has a name for as long as it is a product. Matter does not
            stop being steel, aluminium, timber or glass when a building comes
            down. MatterPassport gives a physical component a persistent
            identity string, then follows that identity through manufacture,
            construction, repair, deconstruction and reassignment — as a
            chain-of-custody record, not a marketing claim.
          </p>
          <div className="grid gap-3 sm:grid-cols-[auto_auto]">
            <Link href="/scan" className="btn btn-primary">
              ▸ Enter the live demo
            </Link>
            <Link href="/building/BLDG-A" className="btn">
              Open building BLDG-A
            </Link>
          </div>
          <Meta
            items={[
              ["Records in this registry", `${stats.materialCount} materials`],
              ["Buildings registered", `${stats.buildingCount}`],
              ["Logged events", `${stats.eventCount}`],
              ["Declared mass under identity", fmtMassKg(stats.trackedMassKg)],
            ]}
          />
        </div>

        {/* Specimen MatterMark */}
        <Panel
          title="MatterMark · specimen"
          code="MP-000184"
          right={
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
              CURRENT IMPLEMENTATION
            </span>
          }
          footer="Carrier-agnostic identity layer. QR is the working carrier of this exhibit; RFID, NFC, laser-etched and optical carriers attach to the same identity without changing the record."
        >
          <div className="grid gap-4 px-4 py-4 sm:grid-cols-[132px_1fr]">
            <div
              className="hair grid aspect-square place-items-center bg-[#08090a] p-2"
              aria-label="MatterMark QR code for MP-000184"
              dangerouslySetInnerHTML={{ __html: mark }}
            />
            <div className="grid content-start gap-2">
              <IdTag code="MP-000184" href="/material/MP-000184" size="lg" />
              <p className="mono text-[11px] leading-relaxed text-[color:var(--color-ink-dim)]">
                Hot-rolled steel column, HEB 200
                <br />
                S355J2 · 214.6 kg · condition A
              </p>
              <p className="text-[12.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
                This is the mark attached to the physical model piece beside
                this screen. Reading it resolves to the passport — the same
                identity string works typed in by hand.
              </p>
              <Link
                href="/material/MP-000184"
                className="mono text-[10.5px] tracking-[0.14em] text-[color:var(--color-accent)] underline uppercase"
              >
                Open this passport ▸
              </Link>
            </div>
          </div>
        </Panel>
      </section>

      {/* TODAY vs MATTERPASSPORT */}
      <section>
        <SectionTitle
          index="01"
          title="Two lifecycles for the same tonne of steel"
          note="Left: the record available today, which ends at demolition. Right: the record this exhibit runs — the identity string survives every handoff, so the same piece of matter can be accounted for twice."
        />
        <div className="grid gap-4 md:grid-cols-2">
          <Column
            title="Today · product identity"
            caption="At demolition the record is destroyed with the building. The matter is still there; nothing can be said about it."
            steps={TODAY}
            tone="today"
          />
          <Column
            title="MatterPassport · matter identity"
            caption="Identity is bound at manufacture and carried by the component. Each transition is an event with an actor, a site and a timestamp."
            steps={LIFECYCLE}
            tone="mp"
          />
        </div>
      </section>

      {/* What the record is */}
      <section className="grid gap-4 lg:grid-cols-3">
        <Panel title="The identity is a string, not a brand" code="01">
          <div className="grid gap-3 px-4 py-4">
            <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
              <span className="mono text-[color:var(--color-ink)]">MP-000184</span>{" "}
              is not a friendly name. It is the primary key of a physical
              object, printed on the object and carried through every screen in
              this exhibit. The descriptive name is subordinate to it, always.
            </p>
            <Note>
              IDs are shown on every screen in monospace. Nothing in this
              interface is identified by a display name alone.
            </Note>
          </div>
        </Panel>
        <Panel title="Declared data, not sensed data" code="02">
          <div className="grid gap-3 px-4 py-4">
            <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
              This prototype has no sensors. Specifications are declared by the
              manufacturer at registration and never presented as measurements.
              Condition is a recorded inspection outcome, not an inference.
            </p>
            <Note>
              Any value that is aggregated, projected or illustrative is
              labelled as such on the screen where it appears.
            </Note>
          </div>
        </Panel>
        <Panel title="Recovery is a rule, not a score" code="03">
          <div className="grid gap-3 px-4 py-4">
            <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
              Every pathway count in the recovery report is produced by the
              stated rule shown next to it, applied to the components actually
              registered to the building being deconstructed. Nothing is
              pre-computed.
            </p>
            <Note tone="accent">
              There is no sustainability score anywhere in this exhibit.
            </Note>
          </div>
        </Panel>
      </section>

      {/* Illustrative future state */}
      <section>
        <SectionTitle
          index="02"
          title="Where this goes — stated once, as a diagram"
          note="The registry in this exhibit is small and complete: every record is on the table. The panel below is the same mechanism at a scale this prototype does not hold data for, and it is drawn as a diagram for that reason."
        />
        <Panel
          title="Future-state network"
          code="ILLUSTRATIVE"
          right={
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-accent)]">
              CONCEPT · NOT LIVE DATA
            </span>
          }
          footer="No counts, no live totals and no network statistics are attached to this diagram. The live, data-backed part of the exhibit begins below."
        >
          <FutureNetwork />
        </Panel>
      </section>

      {/* Live registry */}
      <section>
        <SectionTitle
          index="03"
          title="The live part of the exhibit"
          note={`These are the ${stats.buildingCount} building records and ${stats.materialCount} material identities this instance actually holds. Open one and follow it to deconstruction.`}
        />
        <div className="grid gap-4">
          {buildings.map((b) => {
            const items = materials.filter((m) => m.buildingId === b.id);
            const mass = items.reduce((s, m) => s + m.massKg, 0);
            return (
              <Panel
                key={b.code}
                title={`${b.code} · ${b.name}`}
                code={b.city}
                right={
                  <Link
                    href={
                      b.status === "deconstructed"
                        ? `/deconstruct/${b.code}`
                        : `/building/${b.code}`
                    }
                    className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-accent)] underline uppercase"
                  >
                    Open ▸
                  </Link>
                }
              >
                <div className="grid gap-4 px-4 py-4 md:grid-cols-[1fr_2fr]">
                  <div className="grid gap-2">
                    <StateChip state={b.status === "in_service" ? "in_service" : "registered"} />
                    <dl className="mono grid gap-1 text-[11px] text-[color:var(--color-ink-dim)]">
                      <div className="flex justify-between gap-4">
                        <dt className="label">Status</dt>
                        <dd>{b.status.replace(/_/g, " ").toUpperCase()}</dd>
                      </div>
                      <div className="flex justify-between gap-4">
                        <dt className="label">Floors</dt>
                        <dd>{b.floors}</dd>
                      </div>
                      <div className="flex justify-between gap-4">
                        <dt className="label">Components</dt>
                        <dd>{items.length}</dd>
                      </div>
                      <div className="flex justify-between gap-4">
                        <dt className="label">Declared mass</dt>
                        <dd>{fmtMassKg(mass)}</dd>
                      </div>
                    </dl>
                    <p className="text-[12px] leading-snug text-[color:var(--color-ink-faint)]">
                      {b.structuralSystem}
                    </p>
                  </div>
                  <div className="grid content-start gap-[3px]">
                    {items.slice(0, 6).map((m) => (
                      <Link
                        key={m.code}
                        href={`/material/${m.code}`}
                        className="rule-b flex items-center justify-between gap-3 border-b py-[5px] hover:bg-[#0e1114]"
                      >
                        <span className="mono flex items-center gap-2 text-[11px] text-[color:var(--color-ink-dim)]">
                          <span className="text-[color:var(--color-accent)]">▪</span>
                          {m.code}
                        </span>
                        <span className="truncate text-[12.5px] text-[color:var(--color-ink-dim)]">
                          {m.name}
                        </span>
                        <span className="mono shrink-0 text-[10px] tracking-[0.12em] text-[color:var(--color-ink-faint)]">
                          {STATE_SHORT[m.state as keyof typeof STATE_SHORT] ?? m.state}
                        </span>
                      </Link>
                    ))}
                    {items.length > 6 ? (
                      <span className="mono pt-1 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                        + {items.length - 6} MORE · SEE BUILDING RECORD
                      </span>
                    ) : null}
                  </div>
                </div>
              </Panel>
            );
          })}
        </div>
      </section>
    </div>
  );
}
