import { listMaterials } from "@/lib/data";
import { ScanConsole } from "@/components/scan-console";
import { SectionTitle } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ScanPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const materials = await listMaterials();

  return (
    <div className="grid gap-6">
      <SectionTitle
        index="/ SCAN"
        title="Resolve an identity"
        note="Read the MatterMark attached to a physical model piece, or type the identity string. Both paths resolve the same record: the carrier is disposable, the identity is not."
      />
      <ScanConsole
        autoQuery={q}
        known={materials.map((m) => ({
          code: m.code,
          name: m.name,
          state: m.state,
          locationRef: m.locationRef,
        }))}
      />
    </div>
  );
}
