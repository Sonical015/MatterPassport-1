import {
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * MatterPassport data model.
 *
 * The demo dataset is intentionally small and fully real: every number shown in
 * the UI is derived from these rows. Nothing here stands in for a larger
 * production deployment.
 */

export const buildings = pgTable("buildings", {
  id: integer("id").primaryKey(),
  code: text("code").notNull().unique(), // BLDG-A
  name: text("name").notNull(),
  city: text("city").notNull(),
  status: text("status").notNull(), // in_service | under_construction | deconstructed
  floors: integer("floors").notNull(),
  structuralSystem: text("structural_system").notNull(),
  commissionedAt: text("commissioned_at").notNull(),
  // schematic grid (SVG user units) used by the building page
  gridW: integer("grid_w").notNull(),
  gridH: integer("grid_h").notNull(),
  note: text("note").notNull(),
});

export const materials = pgTable("materials", {
  id: integer("id").primaryKey(),
  code: text("code").notNull().unique(), // MP-000184
  name: text("name").notNull(),
  materialClass: text("material_class").notNull(), // steel | aluminium | timber | concrete | glass | mineral
  componentType: text("component_type").notNull(), // column | beam | panel | glazing | brace | stair | deck
  massKg: doublePrecision("mass_kg").notNull(),
  dimensions: text("dimensions").notNull(),
  condition: text("condition").notNull(), // A | B | C
  // canonical lifecycle state
  state: text("state").notNull(), // manufactured|registered|in_service|repaired|recovered|second_life|recycled|repurposed|unrecoverable
  recommendedPathway: text("recommended_pathway").notNull(), // reuse | recycle | repurpose | unrecoverable
  manufacturer: text("manufacturer").notNull(),
  manufactureSite: text("manufacture_site").notNull(),
  manufacturedAt: text("manufactured_at").notNull(), // ISO date
  batchRef: text("batch_ref").notNull(),
  originBuildingId: integer("origin_building_id"),
  buildingId: integer("building_id"),
  locationRef: text("location_ref").notNull(),
  declaredSpecs: jsonb("declared_specs")
    .$type<Record<string, string>>()
    .notNull()
    .default({}),
  // schematic placement (fractions of the building grid)
  schematic: jsonb("schematic")
    .$type<{
      x: number;
      y: number;
      w: number;
      h: number;
      layer: number;
      label: string;
    }>()
    .notNull()
    .default({ x: 0, y: 0, w: 0, h: 0, layer: 0, label: "" }),
  recoveredFromBuildingId: integer("recovered_from_building_id"),
  recoveryOutcome: text("recovery_outcome"), // reuse | recycle | repurpose | unrecoverable
  secondLifeNote: text("second_life_note"),
});

export const events = pgTable("events", {
  id: integer("id").primaryKey(),
  materialId: integer("material_id").notNull(),
  seq: integer("seq").notNull(),
  type: text("type").notNull(),
  label: text("label").notNull(),
  occurredAt: text("occurred_at").notNull(), // ISO datetime
  actor: text("actor").notNull(),
  site: text("site").notNull(),
  detail: text("detail").notNull(),
});

export const requirements = pgTable("requirements", {
  id: integer("id").primaryKey(),
  code: text("code").notNull(),
  buildingId: integer("building_id").notNull(),
  materialClass: text("material_class").notNull(),
  spec: text("spec").notNull(),
  massRequiredKg: doublePrecision("mass_required_kg").notNull(),
  minCondition: text("min_condition").notNull(), // A | B | C
  status: text("status").notNull(), // open | filled
  filledByMaterialId: integer("filled_by_material_id"),
  openedAt: text("opened_at").notNull(),
});

export type Building = typeof buildings.$inferSelect;
export type Material = typeof materials.$inferSelect;
export type PassportEvent = typeof events.$inferSelect;
export type Requirement = typeof requirements.$inferSelect;
