import { sql } from "drizzle-orm";
import { db } from "@/db";
import { buildings, events, materials, requirements } from "@/db/schema";
import { buildingsSeed, materialsSeed, requirementsSeed } from "./seed-data";

const DDL = [
  `create table if not exists buildings (
    id integer primary key,
    code text not null unique,
    name text not null,
    city text not null,
    status text not null,
    floors integer not null,
    structural_system text not null,
    commissioned_at text not null,
    grid_w integer not null,
    grid_h integer not null,
    note text not null
  )`,
  `create table if not exists materials (
    id integer primary key,
    code text not null unique,
    name text not null,
    material_class text not null,
    component_type text not null,
    mass_kg double precision not null,
    dimensions text not null,
    condition text not null,
    state text not null,
    recommended_pathway text not null,
    manufacturer text not null,
    manufacture_site text not null,
    manufactured_at text not null,
    batch_ref text not null,
    origin_building_id integer,
    building_id integer,
    location_ref text not null,
    declared_specs jsonb not null default '{}'::jsonb,
    schematic jsonb not null default '{"x":0,"y":0,"w":0,"h":0,"layer":0,"label":""}'::jsonb,
    recovered_from_building_id integer,
    recovery_outcome text,
    second_life_note text
  )`,
  `create table if not exists events (
    id integer primary key,
    material_id integer not null,
    seq integer not null,
    type text not null,
    label text not null,
    occurred_at text not null,
    actor text not null,
    site text not null,
    detail text not null
  )`,
  `create table if not exists requirements (
    id integer primary key,
    code text not null,
    building_id integer not null,
    material_class text not null,
    spec text not null,
    mass_required_kg double precision not null,
    min_condition text not null,
    status text not null,
    filled_by_material_id integer,
    opened_at text not null
  )`,
];

async function createTables() {
  for (const statement of DDL) {
    await db.execute(sql.raw(statement));
  }
}

/**
 * Restores the exhibit dataset to its documented state. Called on first boot
 * and by the presentation-mode reset.
 */
export async function resetDemo() {
  await createTables();
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(918273645)`);
    await tx.delete(events);
    await tx.delete(requirements);
    await tx.delete(materials);
    await tx.delete(buildings);
    await tx.insert(buildings).values(buildingsSeed);
    await tx.insert(materials).values(
      materialsSeed.map((m) => ({
        id: m.id,
        code: m.code,
        name: m.name,
        materialClass: m.materialClass,
        componentType: m.componentType,
        massKg: m.massKg,
        dimensions: m.dimensions,
        condition: m.condition,
        state: m.state,
        recommendedPathway: m.recommendedPathway,
        manufacturer: m.manufacturer,
        manufactureSite: m.manufactureSite,
        manufacturedAt: m.manufacturedAt,
        batchRef: m.batchRef,
        originBuildingId: m.originBuildingId,
        buildingId: m.buildingId,
        locationRef: m.locationRef,
        declaredSpecs: m.declaredSpecs,
        schematic: m.schematic,
        recoveredFromBuildingId: m.recoveredFromBuildingId,
        recoveryOutcome: m.recoveredFromBuildingId
          ? m.recommendedPathway
          : null,
        secondLifeNote: m.secondLifeNote,
      })),
    );
    const eventRows: (typeof events.$inferInsert)[] = [];
    let eventId = 1;
    for (const m of materialsSeed) {
      m.events.forEach((e, index) => {
        eventRows.push({
          id: eventId++,
          materialId: m.id,
          seq: index + 1,
          type: e.type,
          label: e.label,
          occurredAt: e.occurredAt,
          actor: e.actor,
          site: e.site,
          detail: e.detail,
        });
      });
    }
    await tx.insert(events).values(eventRows);
    await tx.insert(requirements).values(requirementsSeed);
  });
}

let bootstrap: Promise<void> | null = null;

export function ensureSeeded() {
  if (!bootstrap) {
    bootstrap = (async () => {
      await createTables();
      const result = await db.execute<{ count: string }>(
        sql`select count(*)::text as count from materials`,
      );
      const count = Number(result.rows[0]?.count ?? "0");
      if (count !== materialsSeed.length) {
        await resetDemo();
      }
    })().catch((error) => {
      bootstrap = null;
      throw error;
    });
  }
  return bootstrap;
}
