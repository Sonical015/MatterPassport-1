"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Step = { label: string; detail: string; path: string; dwell: number };

const SCRIPT: Step[] = [
  {
    label: "IDENTIFY",
    detail: "A MatterMark on the physical model is read. Lookup by identity string.",
    path: "/scan?q=MP-000184",
    dwell: 11000,
  },
  {
    label: "PASSPORT",
    detail: "Identity, declared specification and current custody of MP-000184.",
    path: "/material/MP-000184",
    dwell: 12000,
  },
  {
    label: "HISTORY",
    detail: "Logged events only — no sensing, no inference.",
    path: "/material/MP-000184?tab=history",
    dwell: 7000,
  },
  {
    label: "LOCATE",
    detail: "Where the component sits in the registered building.",
    path: "/building/BLDG-A",
    dwell: 11000,
  },
  {
    label: "DECONSTRUCT",
    detail: "The sequence is run against the components actually registered to BLDG-A.",
    path: "/deconstruct/BLDG-A?run=1",
    dwell: 9000,
  },
  {
    label: "RECOVERY REPORT",
    detail: "Counts and mass by pathway, computed from those components.",
    path: "/deconstruct/BLDG-A",
    dwell: 12000,
  },
  {
    label: "SECOND LIFE",
    detail: "A recovered component is matched against open requirements in BLDG-B.",
    path: "/material/MP-000234?tab=future&match=1",
    dwell: 11000,
  },
  {
    label: "COMPARE",
    detail: "Two passports side by side.",
    path: "/compare?a=MP-000184&b=MP-000234",
    dwell: 9000,
  },
  {
    label: "CLOSE",
    detail: "Registry returns to idle. Dataset can be reset at any time.",
    path: "/",
    dwell: 8000,
  },
];

const TOTAL = SCRIPT.reduce((s, x) => s + x.dwell, 0);

export function PresentationMode() {
  const router = useRouter();
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [index, setIndex] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [resetting, setResetting] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const stop = useCallback(() => {
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    setRunning(false);
    setPaused(false);
    setIndex(0);
    setElapsed(0);
  }, []);

  useEffect(() => {
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, []);

  useEffect(() => {
    if (!running || paused) return;
    timer.current = setInterval(() => {
      setElapsed((e) => e + 250);
    }, 250);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [running, paused]);

  useEffect(() => {
    if (!running || paused) return;
    let acc = 0;
    let target = 0;
    for (let i = 0; i <= index; i += 1) acc += SCRIPT[i].dwell;
    target = acc;
    if (elapsed >= target) {
      if (index >= SCRIPT.length - 1) {
        stop();
      } else {
        setIndex((i) => i + 1);
      }
    }
  }, [elapsed, index, paused, running, stop]);

  const goto = useCallback(
    (i: number) => {
      const step = SCRIPT[i];
      if (!step) return;
      setIndex(i);
      router.push(step.path);
    },
    [router],
  );

  const start = useCallback(async () => {
    setResetting(true);
    try {
      await fetch("/api/demo/reset", { method: "POST" });
    } catch {
      /* reset is best-effort; the script still runs */
    }
    setResetting(false);
    setRunning(true);
    setPaused(false);
    setElapsed(0);
    setIndex(0);
    router.push(SCRIPT[0].path);
    router.refresh();
  }, [router]);

  if (!running) {
    return (
      <div className="no-print fixed bottom-0 left-0 z-50">
        <button
          onClick={start}
          disabled={resetting}
          className="mono border border-[color:var(--color-hairline)] border-l-0 border-b-0 bg-[#0b0d0f]/95 px-3 py-2 text-[10px] tracking-[0.18em] text-[color:var(--color-ink-dim)] uppercase backdrop-blur hover:text-[color:var(--color-accent)]"
          title="Auto-advance the full exhibit flow at a fixed pace"
        >
          {resetting ? "RESETTING DATASET…" : "▸ PRESENTATION MODE · 90 s"}
        </button>
      </div>
    );
  }

  const step = SCRIPT[index];
  const stepStart = SCRIPT.slice(0, index).reduce((s, x) => s + x.dwell, 0);
  const stepElapsed = Math.max(0, elapsed - stepStart);

  return (
    <div className="no-print fixed bottom-0 left-0 z-50 w-full border-t border-[color:var(--color-accent-dim)] bg-[#0b0d0f]/97 backdrop-blur">
      <div className="flex flex-wrap items-stretch">
        <div className="flex flex-col justify-center border-r border-[color:var(--color-hairline)] px-4 py-2">
          <span className="label">Presentation mode</span>
          <span className="mono text-[11px] text-[color:var(--color-accent)]">
            RUNNING
          </span>
        </div>
        <div className="min-w-[220px] flex-1 border-r border-[color:var(--color-hairline)] px-4 py-2">
          <div className="flex items-baseline gap-3">
            <span className="mono text-[11px] text-[color:var(--color-accent)]">
              {String(index + 1).padStart(2, "0")}/{String(SCRIPT.length).padStart(2, "0")}
            </span>
            <span className="mono text-[12px] tracking-[0.14em] text-[color:var(--color-ink)]">
              {step.label}
            </span>
          </div>
          <p className="mt-1 text-[12px] text-[color:var(--color-ink-dim)]">
            {step.detail}
          </p>
          <div className="mt-2 flex gap-[3px]">
            {SCRIPT.map((s, i) => (
              <button
                key={s.label}
                onClick={() => goto(i)}
                title={`${s.label} · ${s.dwell / 1000}s`}
                className="h-[6px] flex-1"
                style={{
                  background:
                    i < index
                      ? "var(--color-accent-dim)"
                      : i === index
                        ? "var(--color-accent)"
                        : "var(--color-hairline)",
                }}
              />
            ))}
          </div>
        </div>
        <div className="flex flex-col justify-center border-r border-[color:var(--color-hairline)] px-4 py-2">
          <span className="label">Step</span>
          <span className="mono text-[11px] text-[color:var(--color-ink)]">
            {(stepElapsed / 1000).toFixed(1)}s / {step.dwell / 1000}s
          </span>
          <span className="mono text-[10px] text-[color:var(--color-ink-faint)]">
            total {(elapsed / 1000).toFixed(0)}s / {TOTAL / 1000}s
          </span>
        </div>
        <div className="flex items-center gap-2 px-4 py-2">
          <button
            onClick={() => setPaused((p) => !p)}
            className="btn !py-[6px] !text-[10px]"
          >
            {paused ? "▸ RESUME" : "‖ HOLD"}
          </button>
          <button
            onClick={() =>
              goto(index >= SCRIPT.length - 1 ? 0 : index + 1)
            }
            className="btn !py-[6px] !text-[10px]"
          >
            SKIP ▸
          </button>
          <button
            onClick={stop}
            className="btn !py-[6px] !text-[10px]"
            style={{ borderColor: "var(--color-caution)", color: "var(--color-caution)" }}
          >
            ABORT
          </button>
        </div>
      </div>
    </div>
  );
}
