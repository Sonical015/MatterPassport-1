"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Known = { code: string; name: string; state: string; locationRef: string };

type Result =
  | { kind: "idle" }
  | { kind: "reading"; query: string }
  | { kind: "found"; query: string; material: NonNullable<FoundMaterial> }
  | { kind: "not_found"; query: string }
  | { kind: "unreadable"; source: string };

type FoundMaterial = {
  code: string;
  name: string;
  state: string;
  massKg: number;
  materialClass: string;
  locationRef: string;
};

declare global {
  interface Window {
    BarcodeDetector?: new (options?: { formats?: string[] }) => {
      detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue: string }>>;
    };
  }
}

export function ScanConsole({
  known,
  autoQuery,
}: {
  known: Known[];
  autoQuery?: string;
}) {
  const router = useRouter();
  const [query, setQuery] = useState(autoQuery ?? "");
  const [result, setResult] = useState<Result>({ kind: "idle" });
  const [reader, setReader] = useState<"unavailable" | "idle" | "live" | "error">(
    "idle",
  );
  const [readerNote, setReaderNote] = useState("");
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const loopRef = useRef<number | null>(null);

  const lookup = useCallback(
    async (raw: string, navigate = false) => {
      const value = raw.trim().toUpperCase();
      if (!value) {
        setResult({ kind: "idle" });
        return;
      }
      // A MatterMark URL read by a camera resolves to the identity string.
      const fromUrl = value.match(/\/MATERIAL\/(MP-\d+)$/i);
      const cleaned = fromUrl ? fromUrl[1].toUpperCase() : value;
      setQuery(cleaned);
      setResult({ kind: "reading", query: cleaned });
      try {
        const res = await fetch(`/api/lookup?q=${encodeURIComponent(cleaned)}`);
        if (res.status === 404) {
          setResult({ kind: "not_found", query: cleaned });
          return;
        }
        const data = (await res.json()) as { material: FoundMaterial };
        setResult({ kind: "found", query: cleaned, material: data.material });
        if (navigate) {
          window.setTimeout(() => router.push(`/material/${data.material.code}`), 900);
        }
      } catch {
        setResult({ kind: "not_found", query: cleaned });
      }
    },
    [router],
  );

  const stopReader = useCallback(() => {
    if (loopRef.current) window.clearInterval(loopRef.current);
    loopRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => () => stopReader(), [stopReader]);

  useEffect(() => {
    if (autoQuery) void lookup(autoQuery);
  }, [autoQuery, lookup]);

  const startReader = useCallback(async () => {
    if (typeof window === "undefined") return;
    if (!("BarcodeDetector" in window)) {
      setReader("unavailable");
      setReaderNote(
        "This browser does not expose a barcode detector. Manual identity entry below is the primary path in this exhibit and always works.",
      );
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setReader("live");
      setReaderNote("Reader live. Present a MatterMark from the physical model.");
      const detector = new window.BarcodeDetector!({ formats: ["qr_code"] });
      loopRef.current = window.setInterval(async () => {
        if (!videoRef.current) return;
        try {
          const codes = await detector.detect(videoRef.current);
          if (codes.length > 0) {
            stopReader();
            setReader("idle");
            await lookup(codes[0].rawValue, true);
          }
        } catch {
          /* frame not decodable yet */
        }
      }, 350);
    } catch {
      setReader("error");
      setReaderNote(
        "Camera access refused or unavailable. Manual identity entry below is unaffected.",
      );
    }
  }, [lookup, stopReader]);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,420px)]">
      {/* Reader + manual entry */}
      <div className="grid content-start gap-4">
        <div className="hair">
          <div className="rule-b flex items-center justify-between bg-[#0f1215] px-3 py-2">
            <h2 className="label !text-[color:var(--color-ink-dim)]">
              Carrier reader · camera
            </h2>
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
              OPTIONAL · STRETCH FEATURE
            </span>
          </div>
          <div className="scanlines relative grid place-items-stretch bg-[#08090a]">
            <video
              ref={videoRef}
              muted
              playsInline
              className="aspect-[4/3] w-full object-cover opacity-90"
            />
            {reader !== "live" ? (
              <div className="absolute inset-0 grid place-items-center bg-[#08090a]/92 px-6 text-center">
                <div className="grid gap-3">
                  <span className="mono text-[11px] tracking-[0.2em] text-[color:var(--color-ink-faint)]">
                    {reader === "unavailable"
                      ? "READER NOT SUPPORTED IN THIS BROWSER"
                      : reader === "error"
                        ? "READER FAULT · CAMERA UNAVAILABLE"
                        : "READER IDLE"}
                  </span>
                  <p className="mx-auto max-w-md text-[12.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
                    {readerNote ||
                      "Start the reader to read a MatterMark directly from the physical model, or use manual identity entry — the manual path is the reference implementation of this exhibit."}
                  </p>
                  <div className="flex flex-wrap justify-center gap-2">
                    <button className="btn" onClick={() => void startReader()}>
                      ▸ Start reader
                    </button>
                    <button
                      className="btn"
                      onClick={() => {
                        stopReader();
                        setReader("idle");
                        setReaderNote("");
                        setResult({ kind: "unreadable", source: "mark-presented" });
                      }}
                    >
                      ⌗ Simulate damaged mark
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="pointer-events-none absolute inset-0 grid place-items-center">
                  <div className="h-[46%] w-[52%] border border-[color:var(--color-accent-dim)]">
                    <span className="sweep absolute left-0 h-[1px] w-full bg-[color:var(--color-accent)]/70" />
                  </div>
                </div>
                <span className="mono absolute bottom-2 left-3 text-[10px] tracking-[0.16em] text-[color:var(--color-accent)] blink">
                  READING CARRIER
                </span>
              </>
            )}
          </div>
          <div className="rule-t bg-[#0a0c0e] px-3 py-2 text-[11.5px] text-[color:var(--color-ink-faint)]">
            The camera reads the carrier only. The identity it carries is what
            the registry resolves — a different carrier would resolve the same
            record.
          </div>
        </div>

        <form
          className="hair"
          onSubmit={(e) => {
            e.preventDefault();
            void lookup(query);
          }}
        >
          <div className="rule-b flex items-center justify-between bg-[#0f1215] px-3 py-2">
            <h2 className="label !text-[color:var(--color-ink-dim)]">
              Manual identity entry
            </h2>
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-accent)]">
              REFERENCE PATH
            </span>
          </div>
          <div className="grid gap-3 px-3 py-4">
            <label className="grid gap-1">
              <span className="label">Identity string or building code</span>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value.toUpperCase())}
                placeholder="MP-000184"
                autoComplete="off"
                spellCheck={false}
                className="mono !py-2 !text-[13px] !tracking-[0.12em]"
              />
            </label>
            <div className="flex flex-wrap items-center gap-2">
              <button className="btn btn-primary" type="submit">
                ▸ Resolve identity
              </button>
              <button
                type="button"
                className="btn"
                onClick={() => {
                  setQuery("");
                  setResult({ kind: "idle" });
                }}
              >
                Clear
              </button>
              <span className="mono text-[10px] tracking-[0.12em] text-[color:var(--color-ink-faint)]">
                ACCEPTS MP-####### · PARTIAL STRINGS NOT MATCHED
              </span>
            </div>
          </div>
        </form>
      </div>

      {/* Readout */}
      <div className="grid content-start gap-4">
        <div className="hair">
          <div className="rule-b flex items-center justify-between bg-[#0f1215] px-3 py-2">
            <h2 className="label !text-[color:var(--color-ink-dim)]">
              Lookup readout
            </h2>
            <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
              {result.kind === "idle"
                ? "AWAITING INPUT"
                : result.kind === "reading"
                  ? "QUERYING"
                  : result.kind === "found"
                    ? "RESOLVED"
                    : "FAILED"}
            </span>
          </div>
          <div className="px-3 py-4">
            {result.kind === "idle" ? (
              <div className="grid gap-2">
                <p className="mono text-[12px] leading-relaxed text-[color:var(--color-ink-faint)]">
                  NO QUERY SUBMITTED.
                  <br />
                  ENTER AN IDENTITY STRING OR READ A MATTERMARK.
                </p>
                <p className="text-[12.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
                  The registry holds a small number of records. Nothing is
                  suggested or auto-completed: the identity must be known to
                  the reader, exactly as it would be on a site.
                </p>
              </div>
            ) : null}

            {result.kind === "reading" ? (
              <p className="mono text-[12px] text-[color:var(--color-accent)] blink">
                QUERYING REGISTRY NODE NL-01 FOR {result.query} …
              </p>
            ) : null}

            {result.kind === "found" ? (
              <div className="grid gap-3">
                <div className="grid gap-1">
                  <span className="label">Identity resolved</span>
                  <span className="mono text-[15px] tracking-[0.14em] text-[color:var(--color-ink)]">
                    <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                    {result.material.code}
                  </span>
                </div>
                <dl className="mono grid gap-[6px] text-[11px] text-[color:var(--color-ink-dim)]">
                  {[
                    ["Declared name", result.material.name],
                    ["Class", result.material.materialClass.toUpperCase()],
                    ["Declared mass", `${result.material.massKg.toFixed(1)} kg`],
                    ["State", result.material.state.replace(/_/g, " ").toUpperCase()],
                    ["Location reference", result.material.locationRef],
                  ].map(([k, v]) => (
                    <div key={k} className="grid grid-cols-[140px_1fr] gap-2">
                      <dt className="label">{k}</dt>
                      <dd className="break-words">{v}</dd>
                    </div>
                  ))}
                </dl>
                <Link
                  href={`/material/${result.material.code}`}
                  className="btn btn-primary"
                >
                  ▸ Open passport
                </Link>
              </div>
            ) : null}

            {result.kind === "not_found" ? (
              <div className="grid gap-3">
                <p className="mono text-[12px] leading-relaxed text-[color:var(--color-caution)]">
                  LOOKUP FAILED · {result.query}
                </p>
                <p className="text-[12.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
                  No record with that identity string exists in this registry
                  node. The string was either mistyped, belongs to another
                  node, or was never issued.
                </p>
                <div className="rule-t grid gap-2 pt-3">
                  <span className="label">Recovery options</span>
                  <div className="flex flex-wrap gap-2">
                    <Link href="/ledger" className="btn">
                      Search the ledger
                    </Link>
                    <Link
                      href={`/register?legacy=1&ref=${encodeURIComponent(result.query)}`}
                      className="btn"
                    >
                      Register as legacy material
                    </Link>
                  </div>
                </div>
              </div>
            ) : null}

            {result.kind === "unreadable" ? (
              <div className="grid gap-3">
                <p className="mono text-[13px] tracking-[0.16em] text-[color:var(--color-caution)]">
                  IDENTITY UNREADABLE
                </p>
                <div className="mono grid gap-1 text-[11px] text-[color:var(--color-ink-dim)]">
                  <span>CARRIER: QR · MATTERMARK PRESENTED</span>
                  <span>DECODE ATTEMPTS: 6 · CHECKSUM: NOT RECOVERED</span>
                  <span>FRAMES: 214 · CONTRAST: INSUFFICIENT</span>
                  <span>PHYSICAL DAMAGE OR ABRASION ASSUMED</span>
                </div>
                <p className="text-[12.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
                  The mark is present but cannot be resolved into an identity
                  string. Without an identity, the component is anonymous
                  matter: it has mass, but no history, no declared
                  specification and no second life. This is the failure this
                  exhibit exists to prevent — a component that leaves a
                  building without its record is indistinguishable from one
                  that was never registered.
                </p>
                <div className="rule-t grid gap-2 pt-3">
                  <span className="label">Manual recovery</span>
                  <p className="text-[12px] leading-relaxed text-[color:var(--color-ink-faint)]">
                    If the object can be identified by inspection, a new
                    identity can be issued and the declared specification
                    entered by a registrant. The original history is not
                    recoverable; the new record starts here.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Link
                      href="/register?legacy=1"
                      className="btn btn-primary"
                    >
                      ▸ Register as legacy material
                    </Link>
                    <button
                      className="btn"
                      onClick={() => setResult({ kind: "idle" })}
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>

        <div className="hair">
          <div className="rule-b bg-[#0f1215] px-3 py-2">
            <h2 className="label !text-[color:var(--color-ink-dim)]">
              Identity strings present in this registry
            </h2>
          </div>
          <ul>
            {known.map((k) => (
              <li key={k.code} className="rule-b last:border-b-0">
                <button
                  onClick={() => void lookup(k.code)}
                  className="grid w-full grid-cols-[auto_1fr_auto] items-baseline gap-3 px-3 py-[6px] text-left hover:bg-[#0e1114]"
                >
                  <span className="mono text-[11px] text-[color:var(--color-ink)]">
                    <span className="text-[color:var(--color-accent)]">▪</span>{" "}
                    {k.code}
                  </span>
                  <span className="truncate text-[12.5px] text-[color:var(--color-ink-dim)]">
                    {k.name}
                  </span>
                  <span className="mono text-[10px] tracking-[0.1em] text-[color:var(--color-ink-faint)]">
                    {k.state.replace(/_/g, " ").toUpperCase()}
                  </span>
                </button>
              </li>
            ))}
          </ul>
          <div className="rule-t bg-[#0a0c0e] px-3 py-2 text-[11.5px] text-[color:var(--color-ink-faint)]">
            Listed because this registry is small enough to be legible. In a
            deployed system this list would not exist — only the identity
            string would.
          </div>
        </div>
      </div>
    </div>
  );
}
