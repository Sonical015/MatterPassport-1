"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type Candidate = {
  id: number;
  code: string;
  buildingCode: string;
  buildingName: string;
  materialClass: string;
  spec: string;
  massRequiredKg: number;
  minCondition: string;
  status: string;
  verdict: "MATCH" | "NO MATCH";
  reason: string;
  coverage: number;
};

type MatchData = {
  formula: string;
  material: {
    code: string;
    materialClass: string;
    condition: string;
    massKg: number;
    recoveryOutcome: string | null;
    recommendedPathway: string;
    state: string;
  };
  openRequirementCount: number;
  eligibleOutcomes: string[];
  candidates: Candidate[];
};

export function MatchConsole({
  code,
  auto,
}: {
  code: string;
  auto?: boolean;
}) {
  const [phase, setPhase] = useState<"idle" | "querying" | "done">("idle");
  const [data, setData] = useState<MatchData | null>(null);
  const [assigning, setAssigning] = useState<number | null>(null);
  const [assigned, setAssigned] = useState<{ req: string; building: string } | null>(null);
  const [fault, setFault] = useState("");

  const run = useCallback(async () => {
    setPhase("querying");
    setFault("");
    try {
      const res = await fetch(`/api/materials/${code}/matches`);
      const json = (await res.json()) as MatchData & { ok: boolean; error?: string };
      if (!res.ok || !json.ok) {
        setFault(json.error ?? "registry fault");
        setPhase("idle");
        return;
      }
      setData(json);
      setPhase("done");
    } catch {
      setFault("registry node unreachable");
      setPhase("idle");
    }
  }, [code]);

  useEffect(() => {
    if (auto) void run();
  }, [auto, run]);

  async function assign(candidate: Candidate) {
    setAssigning(candidate.id);
    try {
      const res = await fetch(`/api/materials/${code}/assign`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ requirementId: candidate.id }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!json.ok) {
        setFault(`ASSIGNMENT REFUSED · ${(json.error ?? "unknown").toUpperCase()}`);
      } else {
        setAssigned({
          req: candidate.code,
          building: `${candidate.buildingCode} · ${candidate.buildingName}`,
        });
        await run();
      }
    } catch {
      setFault("ASSIGNMENT REFUSED · REGISTRY NODE UNREACHABLE");
    } finally {
      setAssigning(null);
    }
  }

  if (phase === "idle" && !data) {
    return (
      <div className="grid gap-3 px-4 py-4">
        <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
          The registry holds a small number of open material requirements, each
          attached to a real building record. Matching checks this identity
          against all of them and reports what it finds, including refusals.
        </p>
        <div className="flex flex-wrap gap-2">
          <button className="btn btn-primary" onClick={() => void run()}>
            ▸ Find a second life
          </button>
          {fault ? (
            <span className="mono self-center text-[11px] text-[color:var(--color-caution)]">
              {fault}
            </span>
          ) : null}
        </div>
      </div>
    );
  }

  if (phase === "querying" || !data) {
    return (
      <p className="mono px-4 py-4 text-[12px] text-[color:var(--color-accent)] blink">
        QUERYING OPEN REQUIREMENTS IN REGISTRY NODE NL-01 …
      </p>
    );
  }

  const m = data.material;
  const matches = data.candidates.filter((c) => c.verdict === "MATCH");

  return (
    <div className="grid gap-0">
      <div className="rule-b grid gap-3 bg-[#0b0d0f] px-4 py-3 md:grid-cols-[1fr_auto]">
        <div className="mono grid gap-1 text-[11px] text-[color:var(--color-ink-dim)]">
          <span>
            IDENTITY UNDER TEST · <span className="text-[color:var(--color-ink)]">{m.code}</span>{" "}
            · CLASS {m.materialClass.toUpperCase()} · CONDITION {m.condition} ·{" "}
            {m.massKg.toFixed(1)} kg
          </span>
          <span>
            OPEN REQUIREMENTS IN NODE · {data.openRequirementCount} · MATCHES
            RETURNED ·{" "}
            <span className="text-[color:var(--color-accent)]">{matches.length}</span>
          </span>
          <span className="text-[color:var(--color-ink-faint)]">
            ELIGIBILITY · IDENTITY RELEASED FROM CUSTODY · CLASS EQUAL ·
            CONDITION ≥ THRESHOLD · ASSESSED OUTCOME IS ELEMENT-RETAINING (
            {data.eligibleOutcomes.join(" / ").toUpperCase()})
          </span>
          {m.state !== "recovered" ? (
            <span className="text-[color:var(--color-caution)]">
              THIS IDENTITY IS STILL{" "}
              {m.state.replace(/_/g, " ").toUpperCase()} · NO REQUIREMENT CAN BE
              FILLED UNTIL IT IS RELEASED AT DECONSTRUCTION
            </span>
          ) : null}
        </div>
        <span className="mono self-start border border-[color:var(--color-hairline)] px-2 py-1 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
          {data.formula.toUpperCase()}
        </span>
      </div>

      {assigned ? (
        <div className="rule-b bg-[#0d1009] px-4 py-3">
          <p className="mono text-[11.5px] leading-relaxed text-[color:var(--color-accent)]">
            REASSIGNMENT WRITTEN · {m.code} → {assigned.req} IN {assigned.building}
          </p>
          <p className="mt-1 text-[12.5px] text-[color:var(--color-ink-dim)]">
            The requirement is closed and this identity now carries a second-life
            event. The original building remains in the provenance record.
          </p>
        </div>
      ) : null}

      <div className="overflow-x-auto">
        <table className="ledger">
          <thead>
            <tr>
              <th>Requirement</th>
              <th>Building</th>
              <th>Class</th>
              <th>Specification</th>
              <th className="text-right">Mass req.</th>
              <th>Min cond.</th>
              <th className="text-right">Coverage</th>
              <th>Verdict</th>
              <th>Basis</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {data.candidates.map((c) => (
              <tr key={c.id}>
                <td className="text-[color:var(--color-ink)]">{c.code}</td>
                <td>
                  <Link
                    href={`/building/${c.buildingCode}`}
                    className="hover:text-white hover:underline"
                  >
                    {c.buildingCode}
                  </Link>
                </td>
                <td>{c.materialClass.toUpperCase()}</td>
                <td className="max-w-[220px] text-[color:var(--color-ink-dim)]">
                  {c.spec}
                </td>
                <td className="text-right">{c.massRequiredKg.toFixed(1)} kg</td>
                <td>{c.minCondition}</td>
                <td
                  className="text-right"
                  style={{
                    color:
                      c.verdict === "MATCH"
                        ? "var(--color-accent)"
                        : "var(--color-ink-faint)",
                  }}
                >
                  {c.verdict === "MATCH" ? `${c.coverage}%` : "—"}
                </td>
                <td
                  style={{
                    color:
                      c.verdict === "MATCH"
                        ? "var(--color-accent)"
                        : "var(--color-ink-faint)",
                  }}
                >
                  {c.verdict === "MATCH" ? "● MATCH" : "○ NO MATCH"}
                </td>
                <td className="max-w-[280px] text-[color:var(--color-ink-faint)]">
                  {c.reason}
                </td>
                <td>
                  {c.verdict === "MATCH" ? (
                    <button
                      className="btn !px-2 !py-[4px] !text-[10px]"
                      disabled={assigning === c.id || m.state === "second_life"}
                      onClick={() => void assign(c)}
                    >
                      {assigning === c.id ? "WRITING…" : "ASSIGN ▸"}
                    </button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="rule-t bg-[#0a0c0e] px-4 py-2">
        <p className="text-[12px] leading-relaxed text-[color:var(--color-ink-faint)]">
          Coverage is a mass ratio, nothing more: it says how much of a declared
          requirement this single identity can carry. It is not a compatibility
          score, not a quality judgement, and not derived from anything other
          than the two masses shown. A requirement that returns NO MATCH stays
          open.
        </p>
      </div>
    </div>
  );
}
