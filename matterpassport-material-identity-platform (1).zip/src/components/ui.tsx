import Link from "next/link";
import type { ReactNode } from "react";
import {
  CONDITION_NOTE,
  PATHWAYS,
  STATE_LABEL,
  STATE_NOTE,
  STATE_ORDER,
  STATE_SHORT,
  type LifecycleState,
} from "@/lib/lifecycle";

/* ---------------------------------------------------------------- */
/* IDs are never hidden behind a friendly name                      */
/* ---------------------------------------------------------------- */

export function IdTag({
  code,
  href,
  size = "sm",
}: {
  code: string;
  href?: string;
  size?: "sm" | "lg";
}) {
  const cls =
    size === "lg"
      ? "mono text-[15px] tracking-[0.14em] text-[color:var(--color-ink)]"
      : "mono text-[11px] tracking-[0.1em] text-[color:var(--color-ink-dim)]";
  const body = (
    <span className="inline-flex items-center gap-1.5">
      <span className="text-[color:var(--color-accent)]">▪</span>
      <span className={cls}>{code}</span>
    </span>
  );
  if (href)
    return (
      <Link href={href} className="hover:text-white hover:underline">
        {body}
      </Link>
    );
  return body;
}

export function StateChip({ state }: { state: string }) {
  const key = state as LifecycleState;
  const live = ["in_service", "repaired", "recovered", "second_life"].includes(
    state,
  );
  return (
    <span
      title={STATE_NOTE[key] ?? ""}
      className="mono inline-flex items-center gap-2 border px-2 py-[3px] text-[10px] tracking-[0.14em] uppercase"
      style={{
        borderColor: live ? "var(--color-accent-dim)" : "var(--color-hairline)",
        color: live ? "var(--color-accent)" : "var(--color-ink-dim)",
      }}
    >
      <span className={live ? "blink" : ""}>●</span>
      {STATE_LABEL[key] ?? state}
    </span>
  );
}

export function PathwayTag({ pathway }: { pathway: string }) {
  const p = PATHWAYS.find((x) => x.key === pathway);
  return (
    <span
      title={p?.definition ?? ""}
      className="mono border border-[color:var(--color-hairline)] px-2 py-[3px] text-[10px] tracking-[0.14em] text-[color:var(--color-ink-dim)] uppercase"
    >
      {p?.label ?? pathway}
    </span>
  );
}

export function ConditionTag({ condition }: { condition: string }) {
  return (
    <span
      title={CONDITION_NOTE[condition] ?? ""}
      className="mono inline-flex items-center gap-1.5 border border-[color:var(--color-hairline)] px-2 py-[3px] text-[10px] tracking-[0.14em] text-[color:var(--color-ink-dim)]"
    >
      <span className="text-[color:var(--color-ink-faint)]">COND</span>
      {condition}
    </span>
  );
}

/* ---------------------------------------------------------------- */
/* Panel: hairline box, no shadow, no rounding                      */
/* ---------------------------------------------------------------- */

export function Panel({
  title,
  code,
  right,
  children,
  footer,
  className = "",
}: {
  title: string;
  code?: string;
  right?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  className?: string;
}) {
  return (
    <section className={`hair ${className}`}>
      <header className="rule-b flex items-center justify-between gap-3 bg-[#0f1215] px-3 py-2">
        <div className="flex min-w-0 items-baseline gap-3">
          <h2 className="label truncate !text-[color:var(--color-ink-dim)]">
            {title}
          </h2>
          {code ? (
            <span className="mono text-[10px] tracking-[0.1em] text-[color:var(--color-ink-faint)]">
              {code}
            </span>
          ) : null}
        </div>
        {right ? <div className="shrink-0">{right}</div> : null}
      </header>
      <div>{children}</div>
      {footer ? (
        <footer className="rule-t bg-[#0a0c0e] px-3 py-2 text-[11px] text-[color:var(--color-ink-faint)]">
          {footer}
        </footer>
      ) : null}
    </section>
  );
}

export function SpecRow({
  label,
  value,
  mono = true,
}: {
  label: string;
  value: ReactNode;
  mono?: boolean;
}) {
  return (
    <div className="rule-b grid grid-cols-[minmax(110px,32%)_1fr] gap-3 px-3 py-[7px]">
      <div className="label pt-[2px]">{label}</div>
      <div
        className={
          mono
            ? "mono text-[11.5px] break-words text-[color:var(--color-ink)]"
            : "text-[13px] text-[color:var(--color-ink)]"
        }
      >
        {value}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Deliberate empty / failure states                                */
/* ---------------------------------------------------------------- */

export function FailureState({
  code,
  title,
  lines,
  action,
}: {
  code: string;
  title: string;
  lines: string[];
  action?: ReactNode;
}) {
  return (
    <div className="hair bg-[#0b0d0f]">
      <div className="rule-b flex items-center justify-between bg-[#100c0b] px-3 py-2">
        <span className="mono text-[11px] tracking-[0.18em] text-[color:var(--color-caution)]">
          {title}
        </span>
        <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
          {code}
        </span>
      </div>
      <div className="grid gap-3 px-4 py-5">
        {lines.map((l) => (
          <p key={l} className="mono text-[12px] leading-relaxed text-[color:var(--color-ink-dim)]">
            {l}
          </p>
        ))}
        {action ? <div className="pt-1">{action}</div> : null}
      </div>
    </div>
  );
}

export function Note({
  children,
  tone = "dim",
}: {
  children: ReactNode;
  tone?: "dim" | "accent";
}) {
  return (
    <p
      className="rule-l border-l pl-3 text-[12.5px] leading-relaxed"
      style={{
        borderColor:
          tone === "accent" ? "var(--color-accent-dim)" : "var(--color-hairline)",
        color: tone === "accent" ? "var(--color-ink)" : "var(--color-ink-dim)",
      }}
    >
      {children}
    </p>
  );
}

export function Meta({ items }: { items: Array<[string, string]> }) {
  return (
    <dl className="mono grid grid-cols-2 gap-x-6 gap-y-2 text-[11px] sm:grid-cols-4">
      {items.map(([k, v]) => (
        <div key={k} className="min-w-0">
          <dt className="label">{k}</dt>
          <dd className="truncate text-[color:var(--color-ink)]" title={v}>
            {v}
          </dd>
        </div>
      ))}
    </dl>
  );
}

/* ---------------------------------------------------------------- */
/* Lifecycle: always a linear sequence, never a percentage bar      */
/* ---------------------------------------------------------------- */

export function LifecycleTrack({
  state,
  terminal,
}: {
  state: string;
  terminal?: string | null;
}) {
  const reached = new Set<string>([state]);
  if (state === "repaired") reached.add("in_service");
  if (state === "second_life" || state === "recycled" || state === "repurposed")
    reached.add("recovered");
  if (state === "second_life") {
    reached.add("in_service");
    reached.add("registered");
  }

  return (
    <div className="overflow-x-auto">
      <ol className="flex min-w-[720px] items-stretch">
        {STATE_ORDER.map((s, i) => {
          const done = reached.has(s);
          const current = s === state;
          return (
            <li
              key={s}
              className="relative flex-1 rule-l first:border-l-0"
              style={{
                borderColor: "var(--color-hairline)",
              }}
            >
              <div
                className="absolute top-[13px] left-0 h-[1px] w-full"
                style={{
                  background: done
                    ? "var(--color-accent-dim)"
                    : "var(--color-hairline)",
                }}
              />
              <div className="relative px-3 py-4">
                <span
                  className="block h-[7px] w-[7px]"
                  style={{
                    background: current
                      ? "var(--color-accent)"
                      : done
                        ? "var(--color-accent-dim)"
                        : "var(--color-hairline)",
                  }}
                />
                <div
                  className="mono mt-2 text-[10px] tracking-[0.12em]"
                  style={{
                    color: current
                      ? "var(--color-accent)"
                      : done
                        ? "var(--color-ink-dim)"
                        : "var(--color-ink-faint)",
                  }}
                >
                  {STATE_SHORT[s]}
                </div>
                <div className="mono mt-1 text-[9px] tracking-[0.1em] text-[color:var(--color-ink-faint)]">
                  {current ? "· CURRENT" : done ? "· LOGGED" : "· NOT REACHED"}
                </div>
              </div>
              <span className="mono absolute top-1 right-2 text-[9px] text-[color:var(--color-ink-faint)]">
                {String(i + 1).padStart(2, "0")}
              </span>
            </li>
          );
        })}
        {terminal ? (
          <li
            className="relative flex-1 rule-l"
            style={{ borderColor: "var(--color-hairline)" }}
          >
            <div className="relative px-3 py-4">
              <span
                className="block h-[7px] w-[7px]"
                style={{ background: "var(--color-accent)" }}
              />
              <div className="mono mt-2 text-[10px] tracking-[0.12em] text-[color:var(--color-accent)]">
                {terminal}
              </div>
            </div>
          </li>
        ) : null}
      </ol>
    </div>
  );
}

export function PathwayLegend() {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {PATHWAYS.map((p) => (
        <div key={p.key} className="rule-l border-l pl-3" style={{ borderColor: "var(--color-hairline)" }}>
          <div className="mono text-[10px] tracking-[0.16em] text-[color:var(--color-ink-dim)]">
            {p.label}
          </div>
          <p className="mt-1 text-[12px] leading-snug text-[color:var(--color-ink-faint)]">
            {p.definition}
          </p>
        </div>
      ))}
    </div>
  );
}

export function SectionTitle({
  index,
  title,
  note,
}: {
  index: string;
  title: string;
  note?: string;
}) {
  return (
    <div className="mb-4 grid gap-2">
      <div className="flex items-baseline gap-3">
        <span className="mono text-[10px] tracking-[0.2em] text-[color:var(--color-accent)]">
          {index}
        </span>
        <h2 className="text-[22px] leading-tight text-[color:var(--color-ink)]">
          {title}
        </h2>
      </div>
      {note ? (
        <p className="max-w-2xl text-[13.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
          {note}
        </p>
      ) : null}
    </div>
  );
}
