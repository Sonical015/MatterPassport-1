import Link from "next/link";
import type { Building, Material, PassportEvent } from "@/db/schema";
import {
  fmtMassKg,
  fmtStamp,
  PATHWAYS,
  STATE_LABEL,
  type LifecycleState,
} from "@/lib/lifecycle";

/**
 * Ledger-style one-page document. Rendered on screen at /material/:id/print
 * and injected into the print stylesheet of the passport page.
 */
export function PrintablePassport({
  material,
  events,
  building,
  originBuilding,
  matterMarkSvg,
  printedAt,
}: {
  material: Material;
  events: PassportEvent[];
  building: Building | null;
  originBuilding: Building | null;
  matterMarkSvg: string;
  printedAt: string;
}) {
  const pathway = PATHWAYS.find((p) => p.key === material.recommendedPathway);
  const custody = events.map((e) => e.site);

  return (
    <article className="print-doc hair mx-auto w-full max-w-[820px]">
      <header className="rule-b grid gap-3 px-4 py-3 sm:grid-cols-[1fr_auto]">
        <div>
          <div className="mono text-[11px] tracking-[0.24em]">
            MATTERPASSPORT · MATERIAL PASSPORT
          </div>
          <div className="mono mt-1 text-[9.5px] tracking-[0.18em] text-[color:var(--color-ink-faint)]">
            REGISTRY NODE NL-01 · CHAIN-OF-CUSTODY EXTRACT · SINGLE PAGE
          </div>
          <div className="mono mt-3 text-[26px] leading-none tracking-[0.14em]">
            <span className="text-[color:var(--color-accent)]">▪</span>{" "}
            {material.code}
          </div>
          <div className="mono mt-2 text-[12px] text-[color:var(--color-ink-dim)]">
            {material.name}
          </div>
        </div>
        <div className="grid content-start justify-items-end gap-2">
          <div
            className="hair grid h-[104px] w-[104px] place-items-center bg-[#08090a] p-1"
            dangerouslySetInnerHTML={{ __html: matterMarkSvg }}
          />
          <span className="stamp">PASSPORT ISSUED</span>
        </div>
      </header>

      <section className="rule-b grid gap-0 sm:grid-cols-2">
        <Field label="Identity string" value={material.code} />
        <Field label="Material class" value={material.materialClass.toUpperCase()} />
        <Field label="Component type" value={material.componentType.toUpperCase()} />
        <Field label="Lifecycle state" value={STATE_LABEL[material.state as LifecycleState] ?? material.state} />
        <Field label="Manufacturer (declarant)" value={material.manufacturer} />
        <Field label="Manufacture site" value={`${material.manufactureSite} · ${material.manufacturedAt}`} />
        <Field label="Batch reference" value={material.batchRef} />
        <Field label="Declared mass" value={fmtMassKg(material.massKg)} />
        <Field label="Declared dimensions" value={material.dimensions} />
        <Field label="Recorded condition" value={`${material.condition} · inspection record`} />
        <Field
          label="Current location reference"
          value={material.locationRef}
        />
        <Field
          label="Custody"
          value={
            building
              ? `${building.code} · ${building.name}`
              : "Not in a building record"
          }
        />
        <Field
          label="Building of origin"
          value={
            originBuilding
              ? `${originBuilding.code} · ${originBuilding.name}`
              : "—"
          }
        />
        <Field
          label="Assessed recovery pathway"
          value={`${pathway?.label ?? material.recommendedPathway} · ${
            material.recoveryOutcome ? `outcome ${material.recoveryOutcome.toUpperCase()}` : "not yet assessed"
          }`}
        />
      </section>

      <section className="rule-b px-4 py-3">
        <div className="label">Declared specification set · manufacturer-declared, not sensed</div>
        <table className="ledger mt-2">
          <tbody>
            {Object.entries(material.declaredSpecs ?? {}).map(([k, v]) => (
              <tr key={k}>
                <th className="!border-b-0 w-[38%]">{k}</th>
                <td className="!border-b-0">{v}</td>
              </tr>
            ))}
            {Object.keys(material.declaredSpecs ?? {}).length === 0 ? (
              <tr>
                <td className="!border-b-0 text-[color:var(--color-ink-faint)]">
                  NO DECLARED SPECIFICATION ON RECORD
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </section>

      <section className="rule-b px-4 py-3">
        <div className="label">Chain of custody · from logged events</div>
        <div className="mono mt-2 flex flex-wrap items-center gap-2 text-[10.5px]">
          {custody.map((site, i) => (
            <span key={`${site}-${i}`} className="flex items-center gap-2">
              <span className="border border-[color:var(--color-hairline)] px-2 py-[3px]">
                {site}
              </span>
              {i < custody.length - 1 ? <span className="text-[color:var(--color-ink-faint)]">→</span> : null}
            </span>
          ))}
        </div>
      </section>

      <section className="rule-b px-4 py-3">
        <div className="label">Event ledger · {events.length} entries</div>
        <table className="ledger mt-2">
          <thead>
            <tr>
              <th>Seq</th>
              <th>Event</th>
              <th>Timestamp (UTC)</th>
              <th>Actor</th>
              <th>Entry</th>
            </tr>
          </thead>
          <tbody>
            {events.map((e) => (
              <tr key={e.id}>
                <td>{String(e.seq).padStart(2, "0")}</td>
                <td className="whitespace-nowrap">{e.type}</td>
                <td className="whitespace-nowrap">{fmtStamp(e.occurredAt)}</td>
                <td className="max-w-[180px]">{e.actor}</td>
                <td className="text-[color:var(--color-ink-dim)]">{e.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="rule-b grid gap-3 px-4 py-3 sm:grid-cols-[1fr_auto]">
        <div className="grid gap-2">
          <div className="label">Verification block</div>
          <p className="text-[12px] leading-relaxed text-[color:var(--color-ink-dim)]">
            This document is an extract of a registry record, printed{" "}
            <span className="mono">{printedAt}</span>. It reports declared
            values and logged custody events only. It is not a measurement, not
            a test certificate, and not a statement of condition beyond the
            recorded inspection outcome shown above.
          </p>
          <div className="mono mt-2 grid grid-cols-2 gap-4 text-[10px] text-[color:var(--color-ink-faint)]">
            <span>REGISTRANT ______________________________</span>
            <span>SURVEYOR ______________________________</span>
            <span>DATE ______________________</span>
            <span>REGISTRY NODE NL-01</span>
          </div>
        </div>
        <div className="mono grid content-end justify-items-end gap-1 text-[10px] text-[color:var(--color-ink-faint)]">
          <span>NO SENSING · NO SCORING</span>
          <span>DECLARED + LOGGED ONLY</span>
          <span className="text-[color:var(--color-accent)]">{material.code}</span>
        </div>
      </section>

      <footer className="mono grid gap-1 px-4 py-3 text-[9.5px] tracking-[0.12em] text-[color:var(--color-ink-faint)] sm:grid-cols-[1fr_auto]">
        <span>
          MATTERPASSPORT EXHIBIT PROTOTYPE · DATASET OF THIS NODE · PRINTED
          EXTRACT
        </span>
        <span>
          <Link href={`/material/${material.code}`} className="underline">
            /material/{material.code}
          </Link>{" "}
          · PAGE 1 OF 1
        </span>
      </footer>
    </article>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rule-b grid grid-cols-[46%_1fr] gap-2 border-b px-4 py-[6px] sm:border-r">
      <div className="label pt-[2px]">{label}</div>
      <div className="mono text-[11px] break-words">{value}</div>
    </div>
  );
}
