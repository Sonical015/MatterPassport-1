import Link from "next/link";
import type { Building, Material } from "@/db/schema";
import { STATE_SHORT, type LifecycleState } from "@/lib/lifecycle";

const CLASS_FILL: Record<string, string> = {
  steel: "#2a2f34",
  aluminium: "#242a2e",
  timber: "#2d2a26",
  concrete: "#26292c",
  glass: "#1c2226",
  mineral: "#232527",
  polymer: "#252224",
};

/**
 * Schematic elevation. Component rectangles are placed from the schematic
 * fractions stored on each material record; nothing here is drawn by hand.
 */
export function BuildingSchematic({
  building,
  current,
  vacated,
}: {
  building: Building;
  current: Material[];
  vacated: Material[];
}) {
  const bodyTop = 0.08;
  const bodyBottom = 0.93;
  const bandHeight = (bodyBottom - bodyTop) / building.floors;

  return (
    <div className="grid gap-0">
      <div
        className="relative w-full border border-[color:var(--color-hairline)] bg-[#08090a]"
        style={{ aspectRatio: `${building.gridW} / ${building.gridH}` }}
      >
        {/* floor bands */}
        {Array.from({ length: building.floors }).map((_, i) => {
          const top = bodyTop + i * bandHeight;
          const level = building.floors - i;
          return (
            <div
              key={i}
              className="absolute left-0 w-full"
              style={{
                top: `${top * 100}%`,
                height: `${bandHeight * 100}%`,
                borderTop: "1px solid var(--color-hairline-2)",
              }}
            >
              <span className="mono absolute top-[3px] left-[6px] text-[9px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
                L{String(level).padStart(2, "0")}
              </span>
            </div>
          );
        })}

        {/* vertical grid lines */}
        {[0.2, 0.4, 0.6, 0.8].map((x) => (
          <div
            key={x}
            className="absolute top-0 bottom-0 w-[1px]"
            style={{
              left: `${x * 100}%`,
              background:
                "repeating-linear-gradient(to bottom, var(--color-hairline-2) 0 4px, transparent 4px 10px)",
            }}
          />
        ))}

        {/* structural outline */}
        <div
          className="absolute left-[8%] right-[8%] border-x border-[color:var(--color-hairline)]"
          style={{ top: `${bodyTop * 100}%`, bottom: `${(1 - bodyBottom) * 100}%` }}
        />

        {/* ground line */}
        <div
          className="absolute left-0 w-full border-t border-[color:var(--color-hairline)]"
          style={{ top: `${bodyBottom * 100}%` }}
        >
          <span className="mono absolute top-[3px] left-[6px] text-[9px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
            GROUND
          </span>
        </div>

        {/* components */}
        {[...vacated, ...current].map((m) => {
          const s = m.schematic;
          if (!s || (!s.w && !s.h)) return null;
          const isVacated = !current.some((c) => c.id === m.id);
          return (
            <Link
              key={m.id}
              href={`/material/${m.code}`}
              title={`${m.code} · ${m.name} · ${m.massKg.toFixed(1)} kg · condition ${m.condition} · ${
                STATE_SHORT[m.state as LifecycleState] ?? m.state
              }`}
              className="group absolute grid place-items-center"
              style={{
                left: `${s.x * 100}%`,
                top: `${s.y * 100}%`,
                width: `${Math.max(s.w, 0.012) * 100}%`,
                height: `${Math.max(s.h, 0.012) * 100}%`,
                zIndex: s.layer + 2,
                border: isVacated
                  ? "1px dashed var(--color-ink-faint)"
                  : `1px solid var(--color-ink-dim)`,
                background: isVacated ? "transparent" : CLASS_FILL[m.materialClass],
                opacity: isVacated ? 0.75 : 1,
              }}
            >
              <span
                className="mono pointer-events-none text-[8px] leading-none tracking-[0.08em]"
                style={{
                  color: isVacated
                    ? "var(--color-ink-faint)"
                    : "var(--color-ink-dim)",
                }}
              >
                {s.label}
              </span>
              <span
                className="pointer-events-none absolute -inset-[2px] opacity-0 transition-opacity group-hover:opacity-100"
                style={{ border: "1px solid var(--color-accent)" }}
              />
            </Link>
          );
        })}

        {/* scale + axes chrome */}
        <div className="mono absolute right-[6px] bottom-[4px] text-[8.5px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
          SCHEMATIC ELEVATION · NOT TO SCALE · {building.code}
        </div>
        <div className="mono absolute top-[3px] right-[6px] text-[8.5px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
          {current.length} REGISTERED · {vacated.length} RELEASED
        </div>
      </div>

      <div className="rule-t grid gap-3 bg-[#0a0c0e] px-3 py-3 md:grid-cols-[1fr_auto]">
        <div className="mono flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] tracking-[0.1em] text-[color:var(--color-ink-faint)]">
          {[...new Set(current.map((m) => m.materialClass))].map((c) => (
            <span key={c} className="flex items-center gap-1.5">
              <span
                className="inline-block h-[8px] w-[12px]"
                style={{
                  background: CLASS_FILL[c],
                  border: "1px solid var(--color-ink-dim)",
                }}
              />
              {c.toUpperCase()}
            </span>
          ))}
          <span className="flex items-center gap-1.5">
            <span
              className="inline-block h-[8px] w-[12px]"
              style={{ border: "1px dashed var(--color-ink-faint)" }}
            />
            RELEASED TO RECOVERY
          </span>
        </div>
        <span className="mono text-[10px] tracking-[0.1em] text-[color:var(--color-ink-faint)]">
          EVERY RECTANGLE OPENS A MATERIAL PASSPORT
        </span>
      </div>
    </div>
  );
}
