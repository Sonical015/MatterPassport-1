"use client";

export function PrintButton({ label = "▸ Print / export" }: { label?: string }) {
  return (
    <button className="btn" onClick={() => window.print()}>
      {label}
    </button>
  );
}
