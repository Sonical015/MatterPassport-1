import Link from "next/link";
import type { Building, Material, PassportEvent } from "@/db/schema";
import {
  CONDITION_NOTE,
  fmtMassKg,
  fmtStamp,
  STATE_SHORT,
  type LifecycleState,
} from "@/lib/lifecycle";
import { ConditionTag, PathwayTag, StateChip } from "@/components/ui";

export function CompareCard({
  material,
  other,
  events,
  building,
  originBuilding,
}: {
  material: Material;
  other: Material;
  events: PassportEvent[];
  building: Building | null;
  originBuilding: Building | null;
}) {
  const specKeys = [
    ...new Set([
      ...Object.keys(material.declaredSpecs ?? {}),
      ...Object.keys(other.declaredSpecs ?? {}),
    ]),
  ];
  const stations = events.map((e) => e.site);
  const lastEvent = events[events.length - 1];

  const rows: Array<[string, string, string]> = [
    ["Material class", material.materialClass.toUpperCase(), other.materialClass.toUpperCase()],
    ["Component type", material.componentType.toUpperCase(), other.componentType.toUpperCase()],
    ["Declared mass", fmtMassKg(material.massKg), fmtMassKg(other.massKg)],
    ["Declared dimensions", material.dimensions, other.dimensions],
    ["Manufacturer (declarant)", material.manufacturer, other.manufacturer],
    ["Manufacture site / date", `${material.manufactureSite} · ${material.manufacturedAt}`, `${other.manufactureSite} · ${other.manufacturedAt}`],
    ["Batch reference", material.batchRef, other.batchRef],
    ["Assessed pathway", material.recommendedPathway.toUpperCase(), other.recommendedPathway.toUpperCase()],
    ["Recovery outcome", (material.recoveryOutcome ?? "not assessed").toUpperCase(), (other.recoveryOutcome ?? "not assessed").toUpperCase()],
    ["Current custody", building ? `${building.code} · ${building.name}` : material.locationRef, other.buildingId ? "held in a building record" : other.locationRef],
    ["Building of origin", originBuilding ? originBuilding.code : "—", other.originBuildingId ? "has origin building" : "—"],
    ["Events on file", `${events.length}`, "see specimen A ledger"],
    ["Last logged event", lastEvent ? fmtStamp(lastEvent.occurredAt) : "—", "—"],
  ];

  return (
    <section className="hair grid content-start">
      <div className="rule-b grid gap-3 bg-[#0f1215] px-3 py-3">
        <div className="grid gap-1">
          <span className="mono text-[14px] tracking-[0.12em] text-[color:var(--color-ink)]">
            <span className="text-[color:var(--color-accent)]">▪</span> {material.code}
          </span>
          <Link
            href={`/material/${material.code}`}
            className="text-[15px] leading-snug text-[color:var(--color-ink)] hover:underline"
          >
            {material.name}
          </Link>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StateChip state={material.state} />
          <ConditionTag condition={material.condition} />
          <PathwayTag pathway={material.recommendedPathway} />
        </div>
        <p className="mono text-[10.5px] text-[color:var(--color-ink-faint)]">
          {STATE_SHORT[material.state as LifecycleState] ?? material.state} ·{" "}
          {material.locationRef}
        </p>
      </div>

      <div>
        {rows.map(([label, value, otherValue]) => {
          const differs = value !== otherValue;
          return (
            <div
              key={label}
              className="rule-b grid grid-cols-[42%_1fr] gap-2 border-b px-3 py-[7px]"
              style={{
                borderLeft: differs
                  ? "2px solid var(--color-accent-dim)"
                  : "2px solid transparent",
              }}
            >
              <div className="label pt-[2px]">{label}</div>
              <div className="mono text-[11.5px] break-words text-[color:var(--color-ink)]">
                {value}
              </div>
            </div>
          );
        })}
      </div>

      <div className="rule-b px-3 py-3">
        <span className="label">Declared specification set</span>
        <table className="ledger mt-2">
          <tbody>
            {specKeys.map((k) => {
              const value = material.declaredSpecs?.[k];
              const differs = (material.declaredSpecs?.[k] ?? "—") !== (other.declaredSpecs?.[k] ?? "—");
              return (
                <tr key={k}>
                  <th
                    className="w-[46%]"
                    style={{
                      borderLeft: differs
                        ? "2px solid var(--color-accent-dim)"
                        : "2px solid transparent",
                    }}
                  >
                    {k}
                  </th>
                  <td className="text-[color:var(--color-ink-dim)]">
                    {value ?? <span className="text-[color:var(--color-ink-faint)]">not declared</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="rule-b px-3 py-3">
        <span className="label">Chain of custody</span>
        <div className="mono mt-2 flex flex-wrap items-center gap-[6px] text-[10px] text-[color:var(--color-ink-dim)]">
          {stations.map((s, i) => (
            <span key={`${s}-${i}`} className="flex items-center gap-[6px]">
              <span className="border border-[color:var(--color-hairline)] px-[6px] py-[2px]">
                {s}
              </span>
              {i < stations.length - 1 ? (
                <span className="text-[color:var(--color-ink-faint)]">→</span>
              ) : null}
            </span>
          ))}
        </div>
      </div>

      <div className="px-3 py-3">
        <span className="label">Recorded condition</span>
        <p className="mono mt-1 text-[11px] leading-relaxed text-[color:var(--color-ink-dim)]">
          {material.condition} · {CONDITION_NOTE[material.condition] ?? ""}
        </p>
        <Link
          href={`/material/${material.code}`}
          className="mono mt-3 inline-block text-[10.5px] tracking-[0.14em] text-[color:var(--color-accent)] underline uppercase"
        >
          Open full passport ▸
        </Link>
      </div>
    </section>
  );
}
