"use client";

import { useRouter } from "next/navigation";

export function ComparePicker({
  options,
  a,
  b,
}: {
  options: Array<{ code: string; name: string }>;
  a: string;
  b: string;
}) {
  const router = useRouter();

  const update = (slot: "a" | "b") => (value: string) => {
    const params = new URLSearchParams();
    params.set("a", slot === "a" ? value : a);
    params.set("b", slot === "b" ? value : b);
    router.replace(`/compare?${params.toString()}`, { scroll: false });
  };

  return (
    <div className="hair grid md:grid-cols-2">
      {(["a", "b"] as const).map((slot) => {
        const value = slot === "a" ? a : b;
        return (
          <label
            key={slot}
            className="grid gap-2 px-3 py-3 first:border-b md:first:border-b-0 md:first:border-r md:first:border-b-0"
          >
            <span className="label">
              Specimen {slot.toUpperCase()} · select an identity
            </span>
            <select value={value} onChange={(e) => update(slot)(e.target.value)}>
              {options.map((o) => (
                <option key={o.code} value={o.code}>
                  {o.code} · {o.name}
                </option>
              ))}
            </select>
          </label>
        );
      })}
    </div>
  );
}
