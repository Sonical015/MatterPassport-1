"use client";

import { useRouter, useSearchParams } from "next/navigation";
import type { ReactNode } from "react";

const TABS = [
  { key: "identity", label: "Identity" },
  { key: "physical", label: "Physical" },
  { key: "history", label: "History" },
  { key: "future", label: "Future" },
] as const;

export function PassportTabs({
  code,
  children,
}: {
  code: string;
  children: Record<(typeof TABS)[number]["key"], ReactNode>;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const active = (params.get("tab") ?? "identity") as (typeof TABS)[number]["key"];
  const current = TABS.some((t) => t.key === active) ? active : "identity";

  return (
    <div className="hair">
      <div className="rule-b flex flex-wrap items-stretch bg-[#0f1215]">
        {TABS.map((t) => (
          <button
            key={t.key}
            className="tab"
            data-active={current === t.key}
            onClick={() => {
              const next = new URLSearchParams(params.toString());
              next.set("tab", t.key);
              next.delete("match");
              router.replace(`/material/${code}?${next.toString()}`, { scroll: false });
            }}
          >
            {t.label}
            <span className="ml-2 text-[color:var(--color-ink-faint)]">
              {String(TABS.findIndex((x) => x.key === t.key) + 1).padStart(2, "0")}
            </span>
          </button>
        ))}
        <span className="mono ml-auto self-center px-3 text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
          {code} · RECORD IS APPEND-ONLY
        </span>
      </div>
      <div>{children[current]}</div>
    </div>
  );
}
