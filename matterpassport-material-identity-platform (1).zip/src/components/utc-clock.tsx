"use client";

import { useEffect, useState } from "react";

export function UtcClock() {
  const [now, setNow] = useState<string>("----­--­-- --:--:--");
  useEffect(() => {
    const tick = () => {
      const d = new Date();
      setNow(
        d.toISOString().replace("T", " ").replace(/\.\d+Z$/, " UTC"),
      );
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="mono text-[11px] tracking-[0.06em] text-[color:var(--color-ink-dim)]">
      {now}
    </span>
  );
}
