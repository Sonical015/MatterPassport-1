"use client";

import Link from "next/link";
import { useState } from "react";

type Building = { code: string; name: string };

const CLASSES = ["steel", "aluminium", "timber", "concrete", "glass", "mineral", "polymer"];
const COMPONENTS = [
  "column",
  "beam",
  "panel",
  "glazing",
  "brace",
  "deck",
  "profile",
  "stair",
  "membrane",
  "component",
];
const PATHWAYS = ["reuse", "repurpose", "recycle", "unrecoverable"];

const SPEC_SLOTS = [
  { key: "Grade / standard", placeholder: "S355J2" },
  { key: "Coating / finish", placeholder: "Zinc-rich primer, 80 µm" },
  { key: "Declared embodied carbon", placeholder: "1.24 kgCO₂e/kg" },
  { key: "Additional declaration", placeholder: "e.g. certified origin, adhesive type" },
];

export function RegisterForm({
  buildings,
  legacy,
  legacyRef,
}: {
  buildings: Building[];
  legacy: boolean;
  legacyRef: string;
}) {
  const [form, setForm] = useState({
    name: "",
    materialClass: "steel",
    componentType: "column",
    massKg: "",
    dimensions: "",
    condition: "A",
    manufacturer: "",
    manufactureSite: "",
    manufacturedAt: new Date().toISOString().slice(0, 10),
    batchRef: "",
    recommendedPathway: "reuse",
    locationRef: "",
    buildingCode: "",
  });
  const [specs, setSpecs] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [issued, setIssued] = useState<string | null>(null);

  const set = (key: keyof typeof form) => (value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!form.name.trim() || !Number(form.massKg)) {
      setError(
        "REGISTRATION REJECTED · A DECLARED NAME AND A POSITIVE DECLARED MASS ARE REQUIRED BEFORE AN IDENTITY CAN BE ISSUED.",
      );
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/materials", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ...form,
          massKg: Number(form.massKg),
          declaredSpecs: specs,
        }),
      });
      const data = (await res.json()) as { ok: boolean; code?: string; error?: string };
      if (!data.ok || !data.code) {
        setError(`REGISTRATION REJECTED · ${(data.error ?? "unknown fault").toUpperCase()}`);
      } else {
        setIssued(data.code);
      }
    } catch {
      setError("REGISTRATION REJECTED · REGISTRY NODE UNREACHABLE.");
    } finally {
      setBusy(false);
    }
  }

  if (issued) {
    return (
      <div className="hair">
        <div className="rule-b flex items-center justify-between bg-[#0f1215] px-3 py-2">
          <h2 className="label !text-[color:var(--color-accent)]">
            Identity issued
          </h2>
          <span className="mono text-[10px] tracking-[0.14em] text-[color:var(--color-ink-faint)]">
            REGISTRY NODE NL-01 · WRITE COMPLETE
          </span>
        </div>
        <div className="grid gap-6 px-4 py-5 md:grid-cols-[200px_1fr]">
          <div className="grid gap-2">
            <div className="hair grid aspect-square place-items-center bg-[#08090a] p-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`/api/mattermark?code=${issued}`}
                alt={`MatterMark for ${issued}`}
                className="h-full w-full"
              />
            </div>
            <span className="mono text-[10px] leading-relaxed tracking-[0.12em] text-[color:var(--color-ink-faint)]">
              CURRENT MATTERMARK IMPLEMENTATION · QR, ERROR CORRECTION M
            </span>
          </div>
          <div className="grid content-start gap-4">
            <div className="grid gap-1">
              <span className="label">Material ID</span>
              <span className="mono text-[20px] tracking-[0.16em] text-[color:var(--color-ink)]">
                <span className="text-[color:var(--color-accent)]">▪</span> {issued}
              </span>
            </div>
            <div className="grid gap-2">
              <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
                The identity string is now the primary key of a physical object.
                Two events have been written: a manufacture declaration
                (declared by the registrant, not measured) and the issuance of
                this identity.
              </p>
              <p className="rule-l border-l pl-3 text-[12.5px] leading-relaxed text-[color:var(--color-ink-faint)]" style={{ borderColor: "var(--color-hairline)" }}>
                The identity layer is carrier-agnostic. This QR code is the
                working MatterMark of this exhibit; an RFID tag, an NFC chip, a
                laser-etched code or an optical mark could carry the same
                string without any change to the record behind it.
              </p>
            </div>
            <div className="rule-t grid gap-2 pt-3">
              <span className="label">Next actions</span>
              <div className="flex flex-wrap gap-2">
                <Link href={`/material/${issued}`} className="btn btn-primary">
                  ▸ Open passport
                </Link>
                <Link href={`/material/${issued}/print`} className="btn">
                  Print evidence tag
                </Link>
                <button
                  className="btn"
                  onClick={() => {
                    setIssued(null);
                    setForm((f) => ({ ...f, name: "", massKg: "", dimensions: "", batchRef: "" }));
                    setSpecs({});
                  }}
                >
                  Register another
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-4">
      {legacy ? (
        <div className="hair bg-[#100c0b]">
          <div className="rule-b flex items-center justify-between px-3 py-2">
            <span className="mono text-[11px] tracking-[0.16em] text-[color:var(--color-caution)]">
              LEGACY MATERIAL · NO PRIOR RECORD
            </span>
            {legacyRef ? (
              <span className="mono text-[10px] text-[color:var(--color-ink-faint)]">
                UNRESOLVED STRING: {legacyRef}
              </span>
            ) : null}
          </div>
          <p className="px-3 py-3 text-[12.5px] leading-relaxed text-[color:var(--color-ink-dim)]">
            This registration starts a new record for matter that already
            exists. Anything not declared below is unknown and will remain
            unknown: the registry does not infer properties, and it holds no
            prior history for this object.
          </p>
        </div>
      ) : null}

      <div className="hair">
        <div className="rule-b bg-[#0f1215] px-3 py-2">
          <h2 className="label !text-[color:var(--color-ink-dim)]">
            Declaration · manufacturer
          </h2>
        </div>
        <div className="grid gap-0">
          <Field label="Declared name" required>
            <input
              value={form.name}
              onChange={(e) => set("name")(e.target.value)}
              placeholder="Hot-rolled steel column, HEB 200"
            />
          </Field>
          <div className="grid sm:grid-cols-3">
            <Field label="Material class">
              <select
                value={form.materialClass}
                onChange={(e) => set("materialClass")(e.target.value)}
              >
                {CLASSES.map((c) => (
                  <option key={c} value={c}>
                    {c.toUpperCase()}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Component type">
              <select
                value={form.componentType}
                onChange={(e) => set("componentType")(e.target.value)}
              >
                {COMPONENTS.map((c) => (
                  <option key={c} value={c}>
                    {c.toUpperCase()}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Declared condition">
              <select value={form.condition} onChange={(e) => set("condition")(e.target.value)}>
                <option value="A">A · no recorded defect</option>
                <option value="B">B · defect, section intact</option>
                <option value="C">C · cannot be reused as-declared</option>
              </select>
            </Field>
          </div>
          <div className="grid sm:grid-cols-2">
            <Field label="Declared mass (kg)" required>
              <input
                value={form.massKg}
                onChange={(e) => set("massKg")(e.target.value)}
                inputMode="decimal"
                placeholder="214.6"
              />
            </Field>
            <Field label="Declared dimensions">
              <input
                value={form.dimensions}
                onChange={(e) => set("dimensions")(e.target.value)}
                placeholder="200 × 200 mm × 3.40 m"
              />
            </Field>
          </div>
          <div className="grid sm:grid-cols-2">
            <Field label="Manufacturer">
              <input
                value={form.manufacturer}
                onChange={(e) => set("manufacturer")(e.target.value)}
                placeholder="IJsselstaal BV"
              />
            </Field>
            <Field label="Manufacture site">
              <input
                value={form.manufactureSite}
                onChange={(e) => set("manufactureSite")(e.target.value)}
                placeholder="Rotterdam, NL"
              />
            </Field>
          </div>
          <div className="grid sm:grid-cols-2">
            <Field label="Manufacture date">
              <input
                type="date"
                value={form.manufacturedAt}
                onChange={(e) => set("manufacturedAt")(e.target.value)}
              />
            </Field>
            <Field label="Batch reference">
              <input
                value={form.batchRef}
                onChange={(e) => set("batchRef")(e.target.value)}
                placeholder="IS-B-88141"
              />
            </Field>
          </div>
        </div>
      </div>

      <div className="hair">
        <div className="rule-b bg-[#0f1215] px-3 py-2">
          <h2 className="label !text-[color:var(--color-ink-dim)]">
            Declared specification set
          </h2>
        </div>
        <div className="grid gap-0">
          {SPEC_SLOTS.map((slot) => (
            <Field key={slot.key} label={slot.key}>
              <input
                value={specs[slot.key] ?? ""}
                onChange={(e) =>
                  setSpecs((s) => ({ ...s, [slot.key]: e.target.value }))
                }
                placeholder={slot.placeholder}
              />
            </Field>
          ))}
        </div>
        <p className="rule-t bg-[#0a0c0e] px-3 py-2 text-[11.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
          These values are declared by the registrant. They are stored as
          declarations and rendered as declarations on the passport. Nothing in
          this system measures a physical property.
        </p>
      </div>

      <div className="hair">
        <div className="rule-b bg-[#0f1215] px-3 py-2">
          <h2 className="label !text-[color:var(--color-ink-dim)]">
            Custody · assessed recovery pathway
          </h2>
        </div>
        <div className="grid gap-0 sm:grid-cols-2">
          <Field label="Assessed pathway">
            <select
              value={form.recommendedPathway}
              onChange={(e) => set("recommendedPathway")(e.target.value)}
            >
              {PATHWAYS.map((p) => (
                <option key={p} value={p}>
                  {p.toUpperCase()}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Assign to building (optional)">
            <select
              value={form.buildingCode}
              onChange={(e) => set("buildingCode")(e.target.value)}
            >
              <option value="">· UNASSIGNED ·</option>
              {buildings.map((b) => (
                <option key={b.code} value={b.code}>
                  {b.code} · {b.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Location reference">
          <input
            value={form.locationRef}
            onChange={(e) => set("locationRef")(e.target.value)}
            placeholder={
              form.buildingCode
                ? "L01 · Grid C-3"
                : "Unassigned · not yet in a building"
            }
          />
        </Field>
      </div>

      {error ? (
        <p className="mono hair bg-[#100c0b] px-3 py-3 text-[11.5px] leading-relaxed text-[color:var(--color-caution)]">
          {error}
        </p>
      ) : null}

      <div className="flex flex-wrap items-center gap-3">
        <button className="btn btn-primary" type="submit" disabled={busy}>
          {busy ? "ISSUING…" : "▸ Issue identity + MatterMark"}
        </button>
        <span className="mono text-[10px] tracking-[0.12em] text-[color:var(--color-ink-faint)]">
          WRITE IS IMMEDIATE · RECORDS CANNOT BE EDITED, ONLY APPENDED TO
        </span>
      </div>
    </form>
  );
}

function Field({
  label,
  children,
  required,
}: {
  label: string;
  children: React.ReactNode;
  required?: boolean;
}) {
  return (
    <label className="rule-b grid gap-1 border-b px-3 py-[10px] sm:grid-cols-[190px_1fr] sm:items-center sm:gap-3">
      <span className="label">
        {label}
        {required ? <span className="text-[color:var(--color-accent)]"> *</span> : null}
      </span>
      {children}
    </label>
  );
}
