"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";

type Line = { code: string; massKg: number; outcome: string; condition: string };

export function DeconstructConsole({
  buildingCode,
  buildingName,
  lines,
  auto,
}: {
  buildingCode: string;
  buildingName: string;
  lines: Line[];
  auto?: boolean;
}) {
  const router = useRouter();
  const [phase, setPhase] = useState<"armed" | "running" | "done" | "fault">("armed");
  const [log, setLog] = useState<string[]>([]);
  const [fault, setFault] = useState("");

  const run = useCallback(async () => {
    setPhase("running");
    const write = (line: string) =>
      setLog((prev) => [...prev, line]);

    write(`> CUSTODY TRANSFER OPENED · ${buildingCode} · ${buildingName}`);
    write(`> COMPONENT MANIFEST READ · ${lines.length} IDENTITIES · ${buildingCode}`);
    await sleep(500);

    for (const l of lines) {
      write(
        `> ${l.code} · ${l.massKg.toFixed(1)} kg · CONDITION ${l.condition} · RELEASED · ASSESSED ${l.outcome.toUpperCase()}`,
      );
      await sleep(220);
    }

    write("> ASSESSMENT RULE APPLIED TO EVERY RELEASED IDENTITY");
    await sleep(400);
    write(`> EVENTS WRITTEN · ${lines.length * 2} · BUILDING STATUS SET TO DECONSTRUCTED`);

    try {
      const res = await fetch(`/api/buildings/${buildingCode}/deconstruct`, {
        method: "POST",
      });
      if (!res.ok) {
        const json = (await res.json()) as { reason?: string };
        setFault(json.reason ?? "unknown");
        setPhase("fault");
        return;
      }
      write("> REGISTRY WRITE CONFIRMED · RENDERING RECOVERY REPORT");
      setPhase("done");
      router.refresh();
    } catch {
      setFault("registry node unreachable");
      setPhase("fault");
    }
  }, [buildingCode, buildingName, lines, router]);

  useEffect(() => {
    if (auto) void run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auto]);

  if (phase === "done") {
    return (
      <div className="grid gap-3 px-4 py-4">
        <p className="mono text-[11.5px] leading-relaxed text-[color:var(--color-accent)]">
          SEQUENCE COMPLETE · {lines.length} IDENTITIES PROCESSED · REPORT BELOW
          IS COMPUTED FROM THE REGISTRY
        </p>
        <div className="flex flex-wrap gap-2">
          <button
            className="btn"
            onClick={() => {
              void fetch("/api/demo/reset", { method: "POST" }).then(() =>
                router.refresh(),
              );
            }}
          >
            ↺ Reset exhibit dataset
          </button>
          <a className="btn" href={`/building/${buildingCode}`}>
            ▸ View vacated building record
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-0">
      <div className="grid gap-3 px-4 py-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,360px)]">
        <div className="grid content-start gap-3">
          <p className="text-[13px] leading-relaxed text-[color:var(--color-ink-dim)]">
            Running the sequence releases every identity registered to{" "}
            {buildingCode} from the building record, assesses each one against
            the stated rule, and writes two events per component: a
            deconstruction event and an assessment event. The report is then
            computed from those records — it contains no pre-stored figures.
          </p>
          <div className="mono grid gap-1 text-[11px] text-[color:var(--color-ink-faint)]">
            <span>COMPONENTS TO BE PROCESSED · {lines.length}</span>
            <span>
              DECLARED MASS IN SCOPE ·{" "}
              {lines.reduce((s, l) => s + l.massKg, 0).toFixed(1)} kg
            </span>
            <span>EVENTS TO BE WRITTEN · {lines.length * 2}</span>
          </div>
          {phase === "fault" ? (
            <p className="mono text-[11.5px] text-[color:var(--color-caution)]">
              SEQUENCE REFUSED · {fault.toUpperCase()}
            </p>
          ) : null}
        </div>
        <div className="grid content-start gap-3">
          <span className="label">Warning</span>
          <p className="text-[12.5px] leading-relaxed text-[color:var(--color-ink-faint)]">
            This is a live write against the exhibit dataset. The building
            record becomes deconstructed and its components move to the
            recovery store. The dataset can be restored to its documented state
            at any time.
          </p>
          <button
            className="btn btn-primary !py-3 !text-[12px]"
            onClick={() => void run()}
            disabled={phase === "running"}
          >
            {phase === "running"
              ? "SEQUENCE RUNNING…"
              : "▸ BEGIN DECONSTRUCTION"}
          </button>
        </div>
      </div>

      {log.length > 0 ? (
        <div className="rule-t max-h-[260px] overflow-y-auto bg-[#060708] px-4 py-3">
          <pre className="mono whitespace-pre-wrap text-[11px] leading-relaxed text-[color:var(--color-ink-dim)]">
            {log.join("\n")}
          </pre>
        </div>
      ) : null}
    </div>
  );
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
